/**
 * @license
 * Copyright Nico Schett. All Rights Reserved.
 */
import {BifrostBridge} from 'bridge'

import * as mutations from './mutations.gen'
import * as queries from './queries.gen'

// import * as subscriptions from "./subscriptions.gen";

export default class BridgeDrop {
  public static bridge = new BifrostBridge({
    httpUrl: 'http://localhost:8000/graphql/'
  })

  public static buildIn: {
    mutations: typeof mutations
    queries: typeof queries
    // subscriptions: typeof subscriptions;
  } = {
    mutations: require('./mutations.gen'),
    queries: require('./queries.gen')
    // subscriptions: require("./subscriptions.gen"),
  }
}
