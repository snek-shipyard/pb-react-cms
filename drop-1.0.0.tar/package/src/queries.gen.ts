
/**
 * @license
 * Copyright Nico Schett. All Rights Reserved.
 */

/* tslint:disable */
// This file was automatically generated and should not be edited.

import { GraphqlResult } from "bridge/lib/types";
import gql from "graphql-tag";

import BridgeDrop from "./index";

// @ts-ignore
import { meQuery,meQueryVariables,readStudiePageIndexQuery,readStudiePageIndexQueryVariables,readStudiePageQuery,readStudiePageQueryVariables,readHomePageQuery,readHomePageQueryVariables,readSocialMediaSettingsQuery,readSocialMediaSettingsQueryVariables,pagesQuery,pagesQueryVariables,pageQuery,pageQueryVariables } from "./types.gen";

// ====================================================
// Bridge operation: doMe
// ====================================================

export const doMeQuery = async (
    variables: meQueryVariables
): Promise<GraphqlResult<meQuery>> => {

    const document = gql`fragment userTypeFields_meQuery on UserType { __typename
id
username}
query meQuery($token: String){
me(token: $token) { ...userTypeFields_meQuery}
}
`;

    return await BridgeDrop.bridge.session.query<meQuery>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doReadStudiePageIndex
// ====================================================

export const doReadStudiePageIndexQuery = async (
    variables: readStudiePageIndexQueryVariables
): Promise<GraphqlResult<readStudiePageIndexQuery>> => {

    const document = gql`fragment studiePageIndexFields_readStudiePageIndexQuery on StudiePageIndex { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
url
pageType
seoDescription}
query readStudiePageIndexQuery($id: ID!){
readStudiePageIndex(id: $id) { ...studiePageIndexFields_readStudiePageIndexQuery}
}
`;

    return await BridgeDrop.bridge.session.query<readStudiePageIndexQuery>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doReadStudiePage
// ====================================================

export const doReadStudiePageQuery = async (
    variables: readStudiePageQueryVariables
): Promise<GraphqlResult<readStudiePageQuery>> => {

    const document = gql`fragment streamFieldInterfaceFields_readStudiePageQuery on StreamFieldInterface { __typename
id
blockType
field
rawValue... on StreamFieldBlock{...streamFieldBlockFields_readStudiePageQuery}... on CharBlock{...charBlockFields_readStudiePageQuery}... on TextBlock{...textBlockFields_readStudiePageQuery}... on EmailBlock{...emailBlockFields_readStudiePageQuery}... on IntegerBlock{...integerBlockFields_readStudiePageQuery}... on FloatBlock{...floatBlockFields_readStudiePageQuery}... on DecimalBlock{...decimalBlockFields_readStudiePageQuery}... on RegexBlock{...regexBlockFields_readStudiePageQuery}... on URLBlock{...uRLBlockFields_readStudiePageQuery}... on BooleanBlock{...booleanBlockFields_readStudiePageQuery}... on DateBlock{...dateBlockFields_readStudiePageQuery}... on TimeBlock{...timeBlockFields_readStudiePageQuery}... on DateTimeBlock{...dateTimeBlockFields_readStudiePageQuery}... on RichTextBlock{...richTextBlockFields_readStudiePageQuery}... on RawHTMLBlock{...rawHTMLBlockFields_readStudiePageQuery}... on BlockQuoteBlock{...blockQuoteBlockFields_readStudiePageQuery}... on ChoiceBlock{...choiceBlockFields_readStudiePageQuery}... on StreamBlock{...streamBlockFields_readStudiePageQuery}... on StructBlock{...structBlockFields_readStudiePageQuery}... on StaticBlock{...staticBlockFields_readStudiePageQuery}... on ListBlock{...listBlockFields_readStudiePageQuery}... on EmbedBlock{...embedBlockFields_readStudiePageQuery}... on ImageGalleryImage{...imageGalleryImageFields_readStudiePageQuery}... on ImageGalleryImages{...imageGalleryImagesFields_readStudiePageQuery}... on ImageGalleryBlock{...imageGalleryBlockFields_readStudiePageQuery}... on VideoBlock{...videoBlockFields_readStudiePageQuery}... on DocumentChooserBlock{...documentChooserBlockFields_readStudiePageQuery}... on ImageChooserBlock{...imageChooserBlockFields_readStudiePageQuery}... on SnippetChooserBlock{...snippetChooserBlockFields_readStudiePageQuery}}
fragment streamFieldBlockFields_readStudiePageQuery on StreamFieldBlock { __typename
id
blockType
field
rawValue
value}
fragment charBlockFields_readStudiePageQuery on CharBlock { __typename
id
blockType
field
rawValue
value}
fragment textBlockFields_readStudiePageQuery on TextBlock { __typename
id
blockType
field
rawValue
value}
fragment emailBlockFields_readStudiePageQuery on EmailBlock { __typename
id
blockType
field
rawValue
value}
fragment integerBlockFields_readStudiePageQuery on IntegerBlock { __typename
id
blockType
field
rawValue
value}
fragment floatBlockFields_readStudiePageQuery on FloatBlock { __typename
id
blockType
field
rawValue
value}
fragment decimalBlockFields_readStudiePageQuery on DecimalBlock { __typename
id
blockType
field
rawValue
value}
fragment regexBlockFields_readStudiePageQuery on RegexBlock { __typename
id
blockType
field
rawValue
value}
fragment uRLBlockFields_readStudiePageQuery on URLBlock { __typename
id
blockType
field
rawValue
value}
fragment booleanBlockFields_readStudiePageQuery on BooleanBlock { __typename
id
blockType
field
rawValue
value}
fragment dateBlockFields_readStudiePageQuery on DateBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment timeBlockFields_readStudiePageQuery on TimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment dateTimeBlockFields_readStudiePageQuery on DateTimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment richTextBlockFields_readStudiePageQuery on RichTextBlock { __typename
id
blockType
field
rawValue
value}
fragment rawHTMLBlockFields_readStudiePageQuery on RawHTMLBlock { __typename
id
blockType
field
rawValue
value}
fragment blockQuoteBlockFields_readStudiePageQuery on BlockQuoteBlock { __typename
id
blockType
field
rawValue
value}
fragment choiceOptionFields_readStudiePageQuery on ChoiceOption { __typename
key
value}
fragment choiceBlockFields_readStudiePageQuery on ChoiceBlock { __typename
id
blockType
field
rawValue
value
choices { ...choiceOptionFields_readStudiePageQuery}}
fragment streamBlockFields_readStudiePageQuery on StreamBlock { __typename
id
blockType
field
rawValue}
fragment structBlockFields_readStudiePageQuery on StructBlock { __typename
id
blockType
field
rawValue}
fragment staticBlockFields_readStudiePageQuery on StaticBlock { __typename
id
blockType
field
rawValue
value}
fragment listBlockFields_readStudiePageQuery on ListBlock { __typename
id
blockType
field
rawValue
items{ __typename }}
fragment embedBlockFields_readStudiePageQuery on EmbedBlock { __typename
id
blockType
field
rawValue
value
url
embed
rawEmbed}
fragment imageGalleryImageFields_readStudiePageQuery on ImageGalleryImage { __typename
id
blockType
field
rawValue}
fragment imageGalleryImagesFields_readStudiePageQuery on ImageGalleryImages { __typename
id
blockType
field
rawValue}
fragment imageGalleryBlockFields_readStudiePageQuery on ImageGalleryBlock { __typename
id
blockType
field
rawValue}
fragment videoBlockFields_readStudiePageQuery on VideoBlock { __typename
id
blockType
field
rawValue}
fragment sNEKDocumentFields_readStudiePageQuery on SNEKDocument { __typename
title
file
createdAt
fileSize
fileHash
id}
fragment documentChooserBlockFields_readStudiePageQuery on DocumentChooserBlock { __typename
id
blockType
field
rawValue
document { ...sNEKDocumentFields_readStudiePageQuery}}
fragment renditionFields_readStudiePageQuery on Rendition { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality){ __typename }
srcSet(sizes: $sizes)}
fragment sNEKImageFields_readStudiePageQuery on SNEKImage { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality) { ...renditionFields_readStudiePageQuery}
srcSet(sizes: $sizes)}
fragment imageChooserBlockFields_readStudiePageQuery on ImageChooserBlock { __typename
id
blockType
field
rawValue
image { ...sNEKImageFields_readStudiePageQuery}}
fragment snippetChooserBlockFields_readStudiePageQuery on SnippetChooserBlock { __typename
id
blockType
field
rawValue
snippet}
fragment studiePageFields_readStudiePageQuery on StudiePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
body { ...streamFieldInterfaceFields_readStudiePageQuery}
url
pageType
seoDescription}
query readStudiePageQuery($format: String, $max: String, $min: String, $width: Int, $height: Int, $fill: String, $bgcolor: String, $jpegquality: Int, $sizes: [Int], $id: ID!){
readStudiePage(id: $id) { ...studiePageFields_readStudiePageQuery}
}
`;

    return await BridgeDrop.bridge.session.query<readStudiePageQuery>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doReadHomePage
// ====================================================

export const doReadHomePageQuery = async (
    variables: readHomePageQueryVariables
): Promise<GraphqlResult<readHomePageQuery>> => {

    const document = gql`fragment streamFieldInterfaceFields_readHomePageQuery on StreamFieldInterface { __typename
id
blockType
field
rawValue... on StreamFieldBlock{...streamFieldBlockFields_readHomePageQuery}... on CharBlock{...charBlockFields_readHomePageQuery}... on TextBlock{...textBlockFields_readHomePageQuery}... on EmailBlock{...emailBlockFields_readHomePageQuery}... on IntegerBlock{...integerBlockFields_readHomePageQuery}... on FloatBlock{...floatBlockFields_readHomePageQuery}... on DecimalBlock{...decimalBlockFields_readHomePageQuery}... on RegexBlock{...regexBlockFields_readHomePageQuery}... on URLBlock{...uRLBlockFields_readHomePageQuery}... on BooleanBlock{...booleanBlockFields_readHomePageQuery}... on DateBlock{...dateBlockFields_readHomePageQuery}... on TimeBlock{...timeBlockFields_readHomePageQuery}... on DateTimeBlock{...dateTimeBlockFields_readHomePageQuery}... on RichTextBlock{...richTextBlockFields_readHomePageQuery}... on RawHTMLBlock{...rawHTMLBlockFields_readHomePageQuery}... on BlockQuoteBlock{...blockQuoteBlockFields_readHomePageQuery}... on ChoiceBlock{...choiceBlockFields_readHomePageQuery}... on StreamBlock{...streamBlockFields_readHomePageQuery}... on StructBlock{...structBlockFields_readHomePageQuery}... on StaticBlock{...staticBlockFields_readHomePageQuery}... on ListBlock{...listBlockFields_readHomePageQuery}... on EmbedBlock{...embedBlockFields_readHomePageQuery}... on ImageGalleryImage{...imageGalleryImageFields_readHomePageQuery}... on ImageGalleryImages{...imageGalleryImagesFields_readHomePageQuery}... on ImageGalleryBlock{...imageGalleryBlockFields_readHomePageQuery}... on VideoBlock{...videoBlockFields_readHomePageQuery}... on DocumentChooserBlock{...documentChooserBlockFields_readHomePageQuery}... on ImageChooserBlock{...imageChooserBlockFields_readHomePageQuery}... on SnippetChooserBlock{...snippetChooserBlockFields_readHomePageQuery}}
fragment streamFieldBlockFields_readHomePageQuery on StreamFieldBlock { __typename
id
blockType
field
rawValue
value}
fragment charBlockFields_readHomePageQuery on CharBlock { __typename
id
blockType
field
rawValue
value}
fragment textBlockFields_readHomePageQuery on TextBlock { __typename
id
blockType
field
rawValue
value}
fragment emailBlockFields_readHomePageQuery on EmailBlock { __typename
id
blockType
field
rawValue
value}
fragment integerBlockFields_readHomePageQuery on IntegerBlock { __typename
id
blockType
field
rawValue
value}
fragment floatBlockFields_readHomePageQuery on FloatBlock { __typename
id
blockType
field
rawValue
value}
fragment decimalBlockFields_readHomePageQuery on DecimalBlock { __typename
id
blockType
field
rawValue
value}
fragment regexBlockFields_readHomePageQuery on RegexBlock { __typename
id
blockType
field
rawValue
value}
fragment uRLBlockFields_readHomePageQuery on URLBlock { __typename
id
blockType
field
rawValue
value}
fragment booleanBlockFields_readHomePageQuery on BooleanBlock { __typename
id
blockType
field
rawValue
value}
fragment dateBlockFields_readHomePageQuery on DateBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment timeBlockFields_readHomePageQuery on TimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment dateTimeBlockFields_readHomePageQuery on DateTimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment richTextBlockFields_readHomePageQuery on RichTextBlock { __typename
id
blockType
field
rawValue
value}
fragment rawHTMLBlockFields_readHomePageQuery on RawHTMLBlock { __typename
id
blockType
field
rawValue
value}
fragment blockQuoteBlockFields_readHomePageQuery on BlockQuoteBlock { __typename
id
blockType
field
rawValue
value}
fragment choiceOptionFields_readHomePageQuery on ChoiceOption { __typename
key
value}
fragment choiceBlockFields_readHomePageQuery on ChoiceBlock { __typename
id
blockType
field
rawValue
value
choices { ...choiceOptionFields_readHomePageQuery}}
fragment streamBlockFields_readHomePageQuery on StreamBlock { __typename
id
blockType
field
rawValue}
fragment structBlockFields_readHomePageQuery on StructBlock { __typename
id
blockType
field
rawValue}
fragment staticBlockFields_readHomePageQuery on StaticBlock { __typename
id
blockType
field
rawValue
value}
fragment listBlockFields_readHomePageQuery on ListBlock { __typename
id
blockType
field
rawValue
items{ __typename }}
fragment embedBlockFields_readHomePageQuery on EmbedBlock { __typename
id
blockType
field
rawValue
value
url
embed
rawEmbed}
fragment imageGalleryImageFields_readHomePageQuery on ImageGalleryImage { __typename
id
blockType
field
rawValue}
fragment imageGalleryImagesFields_readHomePageQuery on ImageGalleryImages { __typename
id
blockType
field
rawValue}
fragment imageGalleryBlockFields_readHomePageQuery on ImageGalleryBlock { __typename
id
blockType
field
rawValue}
fragment videoBlockFields_readHomePageQuery on VideoBlock { __typename
id
blockType
field
rawValue}
fragment sNEKDocumentFields_readHomePageQuery on SNEKDocument { __typename
title
file
createdAt
fileSize
fileHash
id}
fragment documentChooserBlockFields_readHomePageQuery on DocumentChooserBlock { __typename
id
blockType
field
rawValue
document { ...sNEKDocumentFields_readHomePageQuery}}
fragment renditionFields_readHomePageQuery on Rendition { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality){ __typename }
srcSet(sizes: $sizes)}
fragment sNEKImageFields_readHomePageQuery on SNEKImage { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality) { ...renditionFields_readHomePageQuery}
srcSet(sizes: $sizes)}
fragment imageChooserBlockFields_readHomePageQuery on ImageChooserBlock { __typename
id
blockType
field
rawValue
image { ...sNEKImageFields_readHomePageQuery}}
fragment snippetChooserBlockFields_readHomePageQuery on SnippetChooserBlock { __typename
id
blockType
field
rawValue
snippet}
fragment homePageFields_readHomePageQuery on HomePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
city
zipCode
address
telephone
telefax
vatNumber
whatsappTelephone
whatsappContactline
taxId
courtOfRegistry
placeOfRegistry
tradeRegisterNumber
ownership
email
copyrightholder
about
privacy
body { ...streamFieldInterfaceFields_readHomePageQuery}
url
pageType
seoDescription}
query readHomePageQuery($format: String, $max: String, $min: String, $width: Int, $height: Int, $fill: String, $bgcolor: String, $jpegquality: Int, $sizes: [Int], $id: ID!){
readHomePage(id: $id) { ...homePageFields_readHomePageQuery}
}
`;

    return await BridgeDrop.bridge.session.query<readHomePageQuery>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doReadSocialMediaSettings
// ====================================================

export const doReadSocialMediaSettingsQuery = async (
    variables: readSocialMediaSettingsQueryVariables
): Promise<GraphqlResult<readSocialMediaSettingsQuery>> => {

    const document = gql`fragment socialMediaSettingsFields_readSocialMediaSettingsQuery on SocialMediaSettings { __typename
id}
query readSocialMediaSettingsQuery($id: ID!){
readSocialMediaSettings(id: $id) { ...socialMediaSettingsFields_readSocialMediaSettingsQuery}
}
`;

    return await BridgeDrop.bridge.session.query<readSocialMediaSettingsQuery>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doPages
// ====================================================

export const doPagesQuery = async (
    variables: pagesQueryVariables
): Promise<GraphqlResult<pagesQuery>> => {

    const document = gql`fragment pageInterfaceFields_pagesQuery on PageInterface { __typename
id
url
urlPath
slug
depth
pageType
title
seoTitle
seoDescription
showInMenus
contentType
lastPublishedAt... on StudiePageIndex{...studiePageIndexFields_pagesQuery}... on StudiePage{...studiePageFields_pagesQuery}... on HomePage{...homePageFields_pagesQuery}... on Page{...pageFields_pagesQuery}}
fragment studiePageIndexFields_pagesQuery on StudiePageIndex { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
url
pageType
seoDescription}
fragment streamFieldInterfaceFields_pagesQuery on StreamFieldInterface { __typename
id
blockType
field
rawValue... on StreamFieldBlock{...streamFieldBlockFields_pagesQuery}... on CharBlock{...charBlockFields_pagesQuery}... on TextBlock{...textBlockFields_pagesQuery}... on EmailBlock{...emailBlockFields_pagesQuery}... on IntegerBlock{...integerBlockFields_pagesQuery}... on FloatBlock{...floatBlockFields_pagesQuery}... on DecimalBlock{...decimalBlockFields_pagesQuery}... on RegexBlock{...regexBlockFields_pagesQuery}... on URLBlock{...uRLBlockFields_pagesQuery}... on BooleanBlock{...booleanBlockFields_pagesQuery}... on DateBlock{...dateBlockFields_pagesQuery}... on TimeBlock{...timeBlockFields_pagesQuery}... on DateTimeBlock{...dateTimeBlockFields_pagesQuery}... on RichTextBlock{...richTextBlockFields_pagesQuery}... on RawHTMLBlock{...rawHTMLBlockFields_pagesQuery}... on BlockQuoteBlock{...blockQuoteBlockFields_pagesQuery}... on ChoiceBlock{...choiceBlockFields_pagesQuery}... on StreamBlock{...streamBlockFields_pagesQuery}... on StructBlock{...structBlockFields_pagesQuery}... on StaticBlock{...staticBlockFields_pagesQuery}... on ListBlock{...listBlockFields_pagesQuery}... on EmbedBlock{...embedBlockFields_pagesQuery}... on ImageGalleryImage{...imageGalleryImageFields_pagesQuery}... on ImageGalleryImages{...imageGalleryImagesFields_pagesQuery}... on ImageGalleryBlock{...imageGalleryBlockFields_pagesQuery}... on VideoBlock{...videoBlockFields_pagesQuery}... on DocumentChooserBlock{...documentChooserBlockFields_pagesQuery}... on ImageChooserBlock{...imageChooserBlockFields_pagesQuery}... on SnippetChooserBlock{...snippetChooserBlockFields_pagesQuery}}
fragment streamFieldBlockFields_pagesQuery on StreamFieldBlock { __typename
id
blockType
field
rawValue
value}
fragment charBlockFields_pagesQuery on CharBlock { __typename
id
blockType
field
rawValue
value}
fragment textBlockFields_pagesQuery on TextBlock { __typename
id
blockType
field
rawValue
value}
fragment emailBlockFields_pagesQuery on EmailBlock { __typename
id
blockType
field
rawValue
value}
fragment integerBlockFields_pagesQuery on IntegerBlock { __typename
id
blockType
field
rawValue
value}
fragment floatBlockFields_pagesQuery on FloatBlock { __typename
id
blockType
field
rawValue
value}
fragment decimalBlockFields_pagesQuery on DecimalBlock { __typename
id
blockType
field
rawValue
value}
fragment regexBlockFields_pagesQuery on RegexBlock { __typename
id
blockType
field
rawValue
value}
fragment uRLBlockFields_pagesQuery on URLBlock { __typename
id
blockType
field
rawValue
value}
fragment booleanBlockFields_pagesQuery on BooleanBlock { __typename
id
blockType
field
rawValue
value}
fragment dateBlockFields_pagesQuery on DateBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment timeBlockFields_pagesQuery on TimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment dateTimeBlockFields_pagesQuery on DateTimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment richTextBlockFields_pagesQuery on RichTextBlock { __typename
id
blockType
field
rawValue
value}
fragment rawHTMLBlockFields_pagesQuery on RawHTMLBlock { __typename
id
blockType
field
rawValue
value}
fragment blockQuoteBlockFields_pagesQuery on BlockQuoteBlock { __typename
id
blockType
field
rawValue
value}
fragment choiceOptionFields_pagesQuery on ChoiceOption { __typename
key
value}
fragment choiceBlockFields_pagesQuery on ChoiceBlock { __typename
id
blockType
field
rawValue
value
choices { ...choiceOptionFields_pagesQuery}}
fragment streamBlockFields_pagesQuery on StreamBlock { __typename
id
blockType
field
rawValue}
fragment structBlockFields_pagesQuery on StructBlock { __typename
id
blockType
field
rawValue}
fragment staticBlockFields_pagesQuery on StaticBlock { __typename
id
blockType
field
rawValue
value}
fragment listBlockFields_pagesQuery on ListBlock { __typename
id
blockType
field
rawValue
items{ __typename }}
fragment embedBlockFields_pagesQuery on EmbedBlock { __typename
id
blockType
field
rawValue
value
url
embed
rawEmbed}
fragment imageGalleryImageFields_pagesQuery on ImageGalleryImage { __typename
id
blockType
field
rawValue}
fragment imageGalleryImagesFields_pagesQuery on ImageGalleryImages { __typename
id
blockType
field
rawValue}
fragment imageGalleryBlockFields_pagesQuery on ImageGalleryBlock { __typename
id
blockType
field
rawValue}
fragment videoBlockFields_pagesQuery on VideoBlock { __typename
id
blockType
field
rawValue}
fragment sNEKDocumentFields_pagesQuery on SNEKDocument { __typename
title
file
createdAt
fileSize
fileHash
id}
fragment documentChooserBlockFields_pagesQuery on DocumentChooserBlock { __typename
id
blockType
field
rawValue
document { ...sNEKDocumentFields_pagesQuery}}
fragment renditionFields_pagesQuery on Rendition { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality){ __typename }
srcSet(sizes: $sizes)}
fragment sNEKImageFields_pagesQuery on SNEKImage { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality) { ...renditionFields_pagesQuery}
srcSet(sizes: $sizes)}
fragment imageChooserBlockFields_pagesQuery on ImageChooserBlock { __typename
id
blockType
field
rawValue
image { ...sNEKImageFields_pagesQuery}}
fragment snippetChooserBlockFields_pagesQuery on SnippetChooserBlock { __typename
id
blockType
field
rawValue
snippet}
fragment studiePageFields_pagesQuery on StudiePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
body { ...streamFieldInterfaceFields_pagesQuery}
url
pageType
seoDescription}
fragment homePageFields_pagesQuery on HomePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
city
zipCode
address
telephone
telefax
vatNumber
whatsappTelephone
whatsappContactline
taxId
courtOfRegistry
placeOfRegistry
tradeRegisterNumber
ownership
email
copyrightholder
about
privacy
body { ...streamFieldInterfaceFields_pagesQuery}
url
pageType
seoDescription}
fragment userTypeFields_pagesQuery on UserType { __typename
id
username}
fragment pageFields_pagesQuery on Page { __typename
id
path
depth
numchild
translationKey
title
draftTitle
slug
contentType
live
hasUnpublishedChanges
urlPath
owner { ...userTypeFields_pagesQuery}
seoTitle
showInMenus
searchDescription
goLiveAt
expireAt
expired
locked
lockedAt
lockedBy { ...userTypeFields_pagesQuery}
firstPublishedAt
lastPublishedAt
latestRevisionCreatedAt
aliasOf{ __typename }
aliases{ __typename }
homepage { ...homePageFields_pagesQuery}
studiepage { ...studiePageFields_pagesQuery}
studiepageindex { ...studiePageIndexFields_pagesQuery}
url
pageType
seoDescription}
query pagesQuery($format: String, $max: String, $min: String, $width: Int, $height: Int, $fill: String, $bgcolor: String, $jpegquality: Int, $sizes: [Int], $token: String, $limit: PositiveInt, $offset: PositiveInt, $order: String, $searchQuery: String, $id: ID){
pages(token: $token, limit: $limit, offset: $offset, order: $order, searchQuery: $searchQuery, id: $id) { ...pageInterfaceFields_pagesQuery}
}
`;

    return await BridgeDrop.bridge.session.query<pagesQuery>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doPage
// ====================================================

export const doPageQuery = async (
    variables: pageQueryVariables
): Promise<GraphqlResult<pageQuery>> => {

    const document = gql`fragment pageInterfaceFields_pageQuery on PageInterface { __typename
id
url
urlPath
slug
depth
pageType
title
seoTitle
seoDescription
showInMenus
contentType
lastPublishedAt... on StudiePageIndex{...studiePageIndexFields_pageQuery}... on StudiePage{...studiePageFields_pageQuery}... on HomePage{...homePageFields_pageQuery}... on Page{...pageFields_pageQuery}}
fragment studiePageIndexFields_pageQuery on StudiePageIndex { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
url
pageType
seoDescription}
fragment streamFieldInterfaceFields_pageQuery on StreamFieldInterface { __typename
id
blockType
field
rawValue... on StreamFieldBlock{...streamFieldBlockFields_pageQuery}... on CharBlock{...charBlockFields_pageQuery}... on TextBlock{...textBlockFields_pageQuery}... on EmailBlock{...emailBlockFields_pageQuery}... on IntegerBlock{...integerBlockFields_pageQuery}... on FloatBlock{...floatBlockFields_pageQuery}... on DecimalBlock{...decimalBlockFields_pageQuery}... on RegexBlock{...regexBlockFields_pageQuery}... on URLBlock{...uRLBlockFields_pageQuery}... on BooleanBlock{...booleanBlockFields_pageQuery}... on DateBlock{...dateBlockFields_pageQuery}... on TimeBlock{...timeBlockFields_pageQuery}... on DateTimeBlock{...dateTimeBlockFields_pageQuery}... on RichTextBlock{...richTextBlockFields_pageQuery}... on RawHTMLBlock{...rawHTMLBlockFields_pageQuery}... on BlockQuoteBlock{...blockQuoteBlockFields_pageQuery}... on ChoiceBlock{...choiceBlockFields_pageQuery}... on StreamBlock{...streamBlockFields_pageQuery}... on StructBlock{...structBlockFields_pageQuery}... on StaticBlock{...staticBlockFields_pageQuery}... on ListBlock{...listBlockFields_pageQuery}... on EmbedBlock{...embedBlockFields_pageQuery}... on ImageGalleryImage{...imageGalleryImageFields_pageQuery}... on ImageGalleryImages{...imageGalleryImagesFields_pageQuery}... on ImageGalleryBlock{...imageGalleryBlockFields_pageQuery}... on VideoBlock{...videoBlockFields_pageQuery}... on DocumentChooserBlock{...documentChooserBlockFields_pageQuery}... on ImageChooserBlock{...imageChooserBlockFields_pageQuery}... on SnippetChooserBlock{...snippetChooserBlockFields_pageQuery}}
fragment streamFieldBlockFields_pageQuery on StreamFieldBlock { __typename
id
blockType
field
rawValue
value}
fragment charBlockFields_pageQuery on CharBlock { __typename
id
blockType
field
rawValue
value}
fragment textBlockFields_pageQuery on TextBlock { __typename
id
blockType
field
rawValue
value}
fragment emailBlockFields_pageQuery on EmailBlock { __typename
id
blockType
field
rawValue
value}
fragment integerBlockFields_pageQuery on IntegerBlock { __typename
id
blockType
field
rawValue
value}
fragment floatBlockFields_pageQuery on FloatBlock { __typename
id
blockType
field
rawValue
value}
fragment decimalBlockFields_pageQuery on DecimalBlock { __typename
id
blockType
field
rawValue
value}
fragment regexBlockFields_pageQuery on RegexBlock { __typename
id
blockType
field
rawValue
value}
fragment uRLBlockFields_pageQuery on URLBlock { __typename
id
blockType
field
rawValue
value}
fragment booleanBlockFields_pageQuery on BooleanBlock { __typename
id
blockType
field
rawValue
value}
fragment dateBlockFields_pageQuery on DateBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment timeBlockFields_pageQuery on TimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment dateTimeBlockFields_pageQuery on DateTimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment richTextBlockFields_pageQuery on RichTextBlock { __typename
id
blockType
field
rawValue
value}
fragment rawHTMLBlockFields_pageQuery on RawHTMLBlock { __typename
id
blockType
field
rawValue
value}
fragment blockQuoteBlockFields_pageQuery on BlockQuoteBlock { __typename
id
blockType
field
rawValue
value}
fragment choiceOptionFields_pageQuery on ChoiceOption { __typename
key
value}
fragment choiceBlockFields_pageQuery on ChoiceBlock { __typename
id
blockType
field
rawValue
value
choices { ...choiceOptionFields_pageQuery}}
fragment streamBlockFields_pageQuery on StreamBlock { __typename
id
blockType
field
rawValue}
fragment structBlockFields_pageQuery on StructBlock { __typename
id
blockType
field
rawValue}
fragment staticBlockFields_pageQuery on StaticBlock { __typename
id
blockType
field
rawValue
value}
fragment listBlockFields_pageQuery on ListBlock { __typename
id
blockType
field
rawValue
items{ __typename }}
fragment embedBlockFields_pageQuery on EmbedBlock { __typename
id
blockType
field
rawValue
value
url
embed
rawEmbed}
fragment imageGalleryImageFields_pageQuery on ImageGalleryImage { __typename
id
blockType
field
rawValue}
fragment imageGalleryImagesFields_pageQuery on ImageGalleryImages { __typename
id
blockType
field
rawValue}
fragment imageGalleryBlockFields_pageQuery on ImageGalleryBlock { __typename
id
blockType
field
rawValue}
fragment videoBlockFields_pageQuery on VideoBlock { __typename
id
blockType
field
rawValue}
fragment sNEKDocumentFields_pageQuery on SNEKDocument { __typename
title
file
createdAt
fileSize
fileHash
id}
fragment documentChooserBlockFields_pageQuery on DocumentChooserBlock { __typename
id
blockType
field
rawValue
document { ...sNEKDocumentFields_pageQuery}}
fragment renditionFields_pageQuery on Rendition { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality){ __typename }
srcSet(sizes: $sizes)}
fragment sNEKImageFields_pageQuery on SNEKImage { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality) { ...renditionFields_pageQuery}
srcSet(sizes: $sizes)}
fragment imageChooserBlockFields_pageQuery on ImageChooserBlock { __typename
id
blockType
field
rawValue
image { ...sNEKImageFields_pageQuery}}
fragment snippetChooserBlockFields_pageQuery on SnippetChooserBlock { __typename
id
blockType
field
rawValue
snippet}
fragment studiePageFields_pageQuery on StudiePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
body { ...streamFieldInterfaceFields_pageQuery}
url
pageType
seoDescription}
fragment homePageFields_pageQuery on HomePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
city
zipCode
address
telephone
telefax
vatNumber
whatsappTelephone
whatsappContactline
taxId
courtOfRegistry
placeOfRegistry
tradeRegisterNumber
ownership
email
copyrightholder
about
privacy
body { ...streamFieldInterfaceFields_pageQuery}
url
pageType
seoDescription}
fragment userTypeFields_pageQuery on UserType { __typename
id
username}
fragment pageFields_pageQuery on Page { __typename
id
path
depth
numchild
translationKey
title
draftTitle
slug
contentType
live
hasUnpublishedChanges
urlPath
owner { ...userTypeFields_pageQuery}
seoTitle
showInMenus
searchDescription
goLiveAt
expireAt
expired
locked
lockedAt
lockedBy { ...userTypeFields_pageQuery}
firstPublishedAt
lastPublishedAt
latestRevisionCreatedAt
aliasOf{ __typename }
aliases{ __typename }
homepage { ...homePageFields_pageQuery}
studiepage { ...studiePageFields_pageQuery}
studiepageindex { ...studiePageIndexFields_pageQuery}
url
pageType
seoDescription}
query pageQuery($format: String, $max: String, $min: String, $width: Int, $height: Int, $fill: String, $bgcolor: String, $jpegquality: Int, $sizes: [Int], $id: ID, $slug: String, $token: String, $contentType: String){
page(id: $id, slug: $slug, token: $token, contentType: $contentType) { ...pageInterfaceFields_pageQuery}
}
`;

    return await BridgeDrop.bridge.session.query<pageQuery>(
      document,
      variables
    );
}
