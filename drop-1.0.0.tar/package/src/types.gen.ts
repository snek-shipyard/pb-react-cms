

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: createHomePageMutation
// ====================================================

export interface createHomePageMutation_createHomePage {
  __typename: "HomePage";
}

export interface createHomePageMutation {
  createHomePage: createHomePageMutation_createHomePage | null;
}

export interface createHomePageMutationVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  input: CreateHomePageInput;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: deleteHomePageMutation
// ====================================================

export interface deleteHomePageMutation {
  deleteHomePage: number | null;
}

export interface deleteHomePageMutationVariables {
  input: DeleteHomePageInput;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: deleteSocialMediaSettingsMutation
// ====================================================

export interface deleteSocialMediaSettingsMutation {
  deleteSocialMediaSettings: number | null;
}

export interface deleteSocialMediaSettingsMutationVariables {
  input: DeleteSocialMediaSettingsInput;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: deleteStudiePageMutation
// ====================================================

export interface deleteStudiePageMutation {
  deleteStudiePage: number | null;
}

export interface deleteStudiePageMutationVariables {
  input: DeleteStudiePageInput;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: deleteStudiePageIndexMutation
// ====================================================

export interface deleteStudiePageIndexMutation {
  deleteStudiePageIndex: number | null;
}

export interface deleteStudiePageIndexMutationVariables {
  input: DeleteStudiePageIndexInput;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: refreshTokenMutation
// ====================================================

export interface refreshTokenMutation_refreshToken {
  __typename: "Refresh";
}

export interface refreshTokenMutation {
  refreshToken: refreshTokenMutation_refreshToken | null;
}

export interface refreshTokenMutationVariables {
  refreshToken?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: revokeTokenMutation
// ====================================================

export interface revokeTokenMutation_revokeToken {
  __typename: "Revoke";
}

export interface revokeTokenMutation {
  revokeToken: revokeTokenMutation_revokeToken | null;
}

export interface revokeTokenMutationVariables {
  refreshToken?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: tokenAuthMutation
// ====================================================

export interface tokenAuthMutation_tokenAuth {
  __typename: "ObtainJSONWebToken";
}

export interface tokenAuthMutation {
  tokenAuth: tokenAuthMutation_tokenAuth | null;
}

export interface tokenAuthMutationVariables {
  username: string;
  password: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: updateHomePageMutation
// ====================================================

export interface updateHomePageMutation_updateHomePage {
  __typename: "HomePage";
}

export interface updateHomePageMutation {
  updateHomePage: updateHomePageMutation_updateHomePage | null;
}

export interface updateHomePageMutationVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  input: UpdateHomePageInput;
  id: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: verifyTokenMutation
// ====================================================

export interface verifyTokenMutation_verifyToken {
  __typename: "Verify";
}

export interface verifyTokenMutation {
  verifyToken: verifyTokenMutation_verifyToken | null;
}

export interface verifyTokenMutationVariables {
  token?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: meQuery
// ====================================================

export interface meQuery_me {
  __typename: "UserType";
}

export interface meQuery {
  me: meQuery_me | null;
}

export interface meQueryVariables {
  token?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: pageQuery
// ====================================================

export interface pageQuery_page {
  __typename: "StudiePageIndex" | "StudiePage" | "HomePage" | "Page";
}

export interface pageQuery {
  page: pageQuery_page | null;
}

export interface pageQueryVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  id?: string | null;
  slug?: string | null;
  token?: string | null;
  contentType?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: pagesQuery
// ====================================================

export interface pagesQuery_pages {
  __typename: "StudiePageIndex" | "StudiePage" | "HomePage" | "Page";
}

export interface pagesQuery {
  pages: pagesQuery_pages[];
}

export interface pagesQueryVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  token?: string | null;
  limit?: any | null;
  offset?: any | null;
  order?: string | null;
  searchQuery?: string | null;
  id?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: readHomePageQuery
// ====================================================

export interface readHomePageQuery_readHomePage {
  __typename: "HomePage";
}

export interface readHomePageQuery {
  readHomePage: readHomePageQuery_readHomePage | null;
}

export interface readHomePageQueryVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  id: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: readSocialMediaSettingsQuery
// ====================================================

export interface readSocialMediaSettingsQuery_readSocialMediaSettings {
  __typename: "SocialMediaSettings";
}

export interface readSocialMediaSettingsQuery {
  readSocialMediaSettings: readSocialMediaSettingsQuery_readSocialMediaSettings | null;
}

export interface readSocialMediaSettingsQueryVariables {
  id: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: readStudiePageQuery
// ====================================================

export interface readStudiePageQuery_readStudiePage {
  __typename: "StudiePage";
}

export interface readStudiePageQuery {
  readStudiePage: readStudiePageQuery_readStudiePage | null;
}

export interface readStudiePageQueryVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  id: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: readStudiePageIndexQuery
// ====================================================

export interface readStudiePageIndexQuery_readStudiePageIndex {
  __typename: "StudiePageIndex";
}

export interface readStudiePageIndexQuery {
  readStudiePageIndex: readStudiePageIndexQuery_readStudiePageIndex | null;
}

export interface readStudiePageIndexQueryVariables {
  id: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL subscription operation: pageSubscription
// ====================================================

export interface pageSubscription_page {
  __typename: "StudiePageIndex" | "StudiePage" | "HomePage" | "Page";
}

export interface pageSubscription {
  page: pageSubscription_page | null;
}

export interface pageSubscriptionVariables {
  format?: string | null;
  max?: string | null;
  min?: string | null;
  width?: number | null;
  height?: number | null;
  fill?: string | null;
  bgcolor?: string | null;
  jpegquality?: number | null;
  sizes?: (number | null)[] | null;
  id?: string | null;
  slug?: string | null;
  token?: string | null;
  contentType?: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_createHomePageMutation
// ====================================================

export interface streamFieldInterfaceFields_createHomePageMutation_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_createHomePageMutation_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_createHomePageMutation = streamFieldInterfaceFields_createHomePageMutation_StreamFieldBlock | streamFieldInterfaceFields_createHomePageMutation_CharBlock | streamFieldInterfaceFields_createHomePageMutation_TextBlock | streamFieldInterfaceFields_createHomePageMutation_EmailBlock | streamFieldInterfaceFields_createHomePageMutation_IntegerBlock | streamFieldInterfaceFields_createHomePageMutation_FloatBlock | streamFieldInterfaceFields_createHomePageMutation_DecimalBlock | streamFieldInterfaceFields_createHomePageMutation_RegexBlock | streamFieldInterfaceFields_createHomePageMutation_URLBlock | streamFieldInterfaceFields_createHomePageMutation_BooleanBlock | streamFieldInterfaceFields_createHomePageMutation_DateBlock | streamFieldInterfaceFields_createHomePageMutation_TimeBlock | streamFieldInterfaceFields_createHomePageMutation_DateTimeBlock | streamFieldInterfaceFields_createHomePageMutation_RichTextBlock | streamFieldInterfaceFields_createHomePageMutation_RawHTMLBlock | streamFieldInterfaceFields_createHomePageMutation_BlockQuoteBlock | streamFieldInterfaceFields_createHomePageMutation_ChoiceBlock | streamFieldInterfaceFields_createHomePageMutation_StreamBlock | streamFieldInterfaceFields_createHomePageMutation_StructBlock | streamFieldInterfaceFields_createHomePageMutation_StaticBlock | streamFieldInterfaceFields_createHomePageMutation_ListBlock | streamFieldInterfaceFields_createHomePageMutation_EmbedBlock | streamFieldInterfaceFields_createHomePageMutation_ImageGalleryImage | streamFieldInterfaceFields_createHomePageMutation_ImageGalleryImages | streamFieldInterfaceFields_createHomePageMutation_ImageGalleryBlock | streamFieldInterfaceFields_createHomePageMutation_VideoBlock | streamFieldInterfaceFields_createHomePageMutation_DocumentChooserBlock | streamFieldInterfaceFields_createHomePageMutation_ImageChooserBlock | streamFieldInterfaceFields_createHomePageMutation_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_createHomePageMutation
// ====================================================

export interface streamFieldBlockFields_createHomePageMutation {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_createHomePageMutation
// ====================================================

export interface charBlockFields_createHomePageMutation {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_createHomePageMutation
// ====================================================

export interface textBlockFields_createHomePageMutation {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_createHomePageMutation
// ====================================================

export interface emailBlockFields_createHomePageMutation {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_createHomePageMutation
// ====================================================

export interface integerBlockFields_createHomePageMutation {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_createHomePageMutation
// ====================================================

export interface floatBlockFields_createHomePageMutation {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_createHomePageMutation
// ====================================================

export interface decimalBlockFields_createHomePageMutation {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_createHomePageMutation
// ====================================================

export interface regexBlockFields_createHomePageMutation {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_createHomePageMutation
// ====================================================

export interface uRLBlockFields_createHomePageMutation {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_createHomePageMutation
// ====================================================

export interface booleanBlockFields_createHomePageMutation {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_createHomePageMutation
// ====================================================

export interface dateBlockFields_createHomePageMutation {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_createHomePageMutation
// ====================================================

export interface timeBlockFields_createHomePageMutation {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_createHomePageMutation
// ====================================================

export interface dateTimeBlockFields_createHomePageMutation {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_createHomePageMutation
// ====================================================

export interface richTextBlockFields_createHomePageMutation {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_createHomePageMutation
// ====================================================

export interface rawHTMLBlockFields_createHomePageMutation {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_createHomePageMutation
// ====================================================

export interface blockQuoteBlockFields_createHomePageMutation {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_createHomePageMutation
// ====================================================

export interface choiceOptionFields_createHomePageMutation {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_createHomePageMutation
// ====================================================

export interface choiceBlockFields_createHomePageMutation_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_createHomePageMutation {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_createHomePageMutation_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_createHomePageMutation
// ====================================================

export interface streamBlockFields_createHomePageMutation {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_createHomePageMutation
// ====================================================

export interface structBlockFields_createHomePageMutation {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_createHomePageMutation
// ====================================================

export interface staticBlockFields_createHomePageMutation {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_createHomePageMutation
// ====================================================

export interface listBlockFields_createHomePageMutation_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_createHomePageMutation {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_createHomePageMutation_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_createHomePageMutation
// ====================================================

export interface embedBlockFields_createHomePageMutation {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_createHomePageMutation
// ====================================================

export interface imageGalleryImageFields_createHomePageMutation {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_createHomePageMutation
// ====================================================

export interface imageGalleryImagesFields_createHomePageMutation {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_createHomePageMutation
// ====================================================

export interface imageGalleryBlockFields_createHomePageMutation {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_createHomePageMutation
// ====================================================

export interface videoBlockFields_createHomePageMutation {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_createHomePageMutation
// ====================================================

export interface sNEKDocumentFields_createHomePageMutation {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_createHomePageMutation
// ====================================================

export interface documentChooserBlockFields_createHomePageMutation_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_createHomePageMutation {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_createHomePageMutation_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_createHomePageMutation
// ====================================================

export interface renditionFields_createHomePageMutation_rendition {
  __typename: "Rendition";
}

export interface renditionFields_createHomePageMutation {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_createHomePageMutation_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_createHomePageMutation
// ====================================================

export interface sNEKImageFields_createHomePageMutation_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_createHomePageMutation {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_createHomePageMutation_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_createHomePageMutation
// ====================================================

export interface imageChooserBlockFields_createHomePageMutation_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_createHomePageMutation {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_createHomePageMutation_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_createHomePageMutation
// ====================================================

export interface snippetChooserBlockFields_createHomePageMutation {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: homePageFields_createHomePageMutation
// ====================================================

export interface homePageFields_createHomePageMutation_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface homePageFields_createHomePageMutation {
  __typename: "HomePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  city: string;
  zipCode: string;
  address: string;
  telephone: string;
  telefax: string;
  vatNumber: string;
  whatsappTelephone: string;
  whatsappContactline: string;
  taxId: string;
  courtOfRegistry: string;
  placeOfRegistry: string;
  tradeRegisterNumber: string;
  ownership: string;
  email: string;
  copyrightholder: string;
  about: string;
  privacy: string;
  body: (homePageFields_createHomePageMutation_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: refreshFields_refreshTokenMutation
// ====================================================

export interface refreshFields_refreshTokenMutation {
  __typename: "Refresh";
  payload: any;
  refreshExpiresIn: number;
  token: string;
  refreshToken: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: revokeFields_revokeTokenMutation
// ====================================================

export interface revokeFields_revokeTokenMutation {
  __typename: "Revoke";
  revoked: number;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: userTypeFields_tokenAuthMutation
// ====================================================

export interface userTypeFields_tokenAuthMutation {
  __typename: "UserType";
  id: string;
  username: string | null;  // Required. 36 characters or fewer. Letters, digits and @/./+/-/_ only.
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: obtainJSONWebTokenFields_tokenAuthMutation
// ====================================================

export interface obtainJSONWebTokenFields_tokenAuthMutation_user {
  __typename: "UserType";
}

export interface obtainJSONWebTokenFields_tokenAuthMutation {
  __typename: "ObtainJSONWebToken";
  payload: any;
  refreshExpiresIn: number;
  user: obtainJSONWebTokenFields_tokenAuthMutation_user | null;
  token: string;
  refreshToken: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_updateHomePageMutation
// ====================================================

export interface streamFieldInterfaceFields_updateHomePageMutation_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_updateHomePageMutation_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_updateHomePageMutation = streamFieldInterfaceFields_updateHomePageMutation_StreamFieldBlock | streamFieldInterfaceFields_updateHomePageMutation_CharBlock | streamFieldInterfaceFields_updateHomePageMutation_TextBlock | streamFieldInterfaceFields_updateHomePageMutation_EmailBlock | streamFieldInterfaceFields_updateHomePageMutation_IntegerBlock | streamFieldInterfaceFields_updateHomePageMutation_FloatBlock | streamFieldInterfaceFields_updateHomePageMutation_DecimalBlock | streamFieldInterfaceFields_updateHomePageMutation_RegexBlock | streamFieldInterfaceFields_updateHomePageMutation_URLBlock | streamFieldInterfaceFields_updateHomePageMutation_BooleanBlock | streamFieldInterfaceFields_updateHomePageMutation_DateBlock | streamFieldInterfaceFields_updateHomePageMutation_TimeBlock | streamFieldInterfaceFields_updateHomePageMutation_DateTimeBlock | streamFieldInterfaceFields_updateHomePageMutation_RichTextBlock | streamFieldInterfaceFields_updateHomePageMutation_RawHTMLBlock | streamFieldInterfaceFields_updateHomePageMutation_BlockQuoteBlock | streamFieldInterfaceFields_updateHomePageMutation_ChoiceBlock | streamFieldInterfaceFields_updateHomePageMutation_StreamBlock | streamFieldInterfaceFields_updateHomePageMutation_StructBlock | streamFieldInterfaceFields_updateHomePageMutation_StaticBlock | streamFieldInterfaceFields_updateHomePageMutation_ListBlock | streamFieldInterfaceFields_updateHomePageMutation_EmbedBlock | streamFieldInterfaceFields_updateHomePageMutation_ImageGalleryImage | streamFieldInterfaceFields_updateHomePageMutation_ImageGalleryImages | streamFieldInterfaceFields_updateHomePageMutation_ImageGalleryBlock | streamFieldInterfaceFields_updateHomePageMutation_VideoBlock | streamFieldInterfaceFields_updateHomePageMutation_DocumentChooserBlock | streamFieldInterfaceFields_updateHomePageMutation_ImageChooserBlock | streamFieldInterfaceFields_updateHomePageMutation_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_updateHomePageMutation
// ====================================================

export interface streamFieldBlockFields_updateHomePageMutation {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_updateHomePageMutation
// ====================================================

export interface charBlockFields_updateHomePageMutation {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_updateHomePageMutation
// ====================================================

export interface textBlockFields_updateHomePageMutation {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_updateHomePageMutation
// ====================================================

export interface emailBlockFields_updateHomePageMutation {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_updateHomePageMutation
// ====================================================

export interface integerBlockFields_updateHomePageMutation {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_updateHomePageMutation
// ====================================================

export interface floatBlockFields_updateHomePageMutation {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_updateHomePageMutation
// ====================================================

export interface decimalBlockFields_updateHomePageMutation {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_updateHomePageMutation
// ====================================================

export interface regexBlockFields_updateHomePageMutation {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_updateHomePageMutation
// ====================================================

export interface uRLBlockFields_updateHomePageMutation {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_updateHomePageMutation
// ====================================================

export interface booleanBlockFields_updateHomePageMutation {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_updateHomePageMutation
// ====================================================

export interface dateBlockFields_updateHomePageMutation {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_updateHomePageMutation
// ====================================================

export interface timeBlockFields_updateHomePageMutation {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_updateHomePageMutation
// ====================================================

export interface dateTimeBlockFields_updateHomePageMutation {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_updateHomePageMutation
// ====================================================

export interface richTextBlockFields_updateHomePageMutation {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_updateHomePageMutation
// ====================================================

export interface rawHTMLBlockFields_updateHomePageMutation {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_updateHomePageMutation
// ====================================================

export interface blockQuoteBlockFields_updateHomePageMutation {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_updateHomePageMutation
// ====================================================

export interface choiceOptionFields_updateHomePageMutation {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_updateHomePageMutation
// ====================================================

export interface choiceBlockFields_updateHomePageMutation_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_updateHomePageMutation {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_updateHomePageMutation_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_updateHomePageMutation
// ====================================================

export interface streamBlockFields_updateHomePageMutation {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_updateHomePageMutation
// ====================================================

export interface structBlockFields_updateHomePageMutation {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_updateHomePageMutation
// ====================================================

export interface staticBlockFields_updateHomePageMutation {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_updateHomePageMutation
// ====================================================

export interface listBlockFields_updateHomePageMutation_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_updateHomePageMutation {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_updateHomePageMutation_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_updateHomePageMutation
// ====================================================

export interface embedBlockFields_updateHomePageMutation {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_updateHomePageMutation
// ====================================================

export interface imageGalleryImageFields_updateHomePageMutation {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_updateHomePageMutation
// ====================================================

export interface imageGalleryImagesFields_updateHomePageMutation {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_updateHomePageMutation
// ====================================================

export interface imageGalleryBlockFields_updateHomePageMutation {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_updateHomePageMutation
// ====================================================

export interface videoBlockFields_updateHomePageMutation {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_updateHomePageMutation
// ====================================================

export interface sNEKDocumentFields_updateHomePageMutation {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_updateHomePageMutation
// ====================================================

export interface documentChooserBlockFields_updateHomePageMutation_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_updateHomePageMutation {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_updateHomePageMutation_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_updateHomePageMutation
// ====================================================

export interface renditionFields_updateHomePageMutation_rendition {
  __typename: "Rendition";
}

export interface renditionFields_updateHomePageMutation {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_updateHomePageMutation_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_updateHomePageMutation
// ====================================================

export interface sNEKImageFields_updateHomePageMutation_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_updateHomePageMutation {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_updateHomePageMutation_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_updateHomePageMutation
// ====================================================

export interface imageChooserBlockFields_updateHomePageMutation_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_updateHomePageMutation {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_updateHomePageMutation_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_updateHomePageMutation
// ====================================================

export interface snippetChooserBlockFields_updateHomePageMutation {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: homePageFields_updateHomePageMutation
// ====================================================

export interface homePageFields_updateHomePageMutation_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface homePageFields_updateHomePageMutation {
  __typename: "HomePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  city: string;
  zipCode: string;
  address: string;
  telephone: string;
  telefax: string;
  vatNumber: string;
  whatsappTelephone: string;
  whatsappContactline: string;
  taxId: string;
  courtOfRegistry: string;
  placeOfRegistry: string;
  tradeRegisterNumber: string;
  ownership: string;
  email: string;
  copyrightholder: string;
  about: string;
  privacy: string;
  body: (homePageFields_updateHomePageMutation_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: verifyFields_verifyTokenMutation
// ====================================================

export interface verifyFields_verifyTokenMutation {
  __typename: "Verify";
  payload: any;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: userTypeFields_meQuery
// ====================================================

export interface userTypeFields_meQuery {
  __typename: "UserType";
  id: string;
  username: string | null;  // Required. 36 characters or fewer. Letters, digits and @/./+/-/_ only.
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: pageInterfaceFields_pageQuery
// ====================================================

export interface pageInterfaceFields_pageQuery_StudiePageIndex {
  __typename: "StudiePageIndex";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pageQuery_StudiePage {
  __typename: "StudiePage";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pageQuery_HomePage {
  __typename: "HomePage";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pageQuery_Page {
  __typename: "Page";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export type pageInterfaceFields_pageQuery = pageInterfaceFields_pageQuery_StudiePageIndex | pageInterfaceFields_pageQuery_StudiePage | pageInterfaceFields_pageQuery_HomePage | pageInterfaceFields_pageQuery_Page;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageIndexFields_pageQuery
// ====================================================

export interface studiePageIndexFields_pageQuery {
  __typename: "StudiePageIndex";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_pageQuery
// ====================================================

export interface streamFieldInterfaceFields_pageQuery_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageQuery_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_pageQuery = streamFieldInterfaceFields_pageQuery_StreamFieldBlock | streamFieldInterfaceFields_pageQuery_CharBlock | streamFieldInterfaceFields_pageQuery_TextBlock | streamFieldInterfaceFields_pageQuery_EmailBlock | streamFieldInterfaceFields_pageQuery_IntegerBlock | streamFieldInterfaceFields_pageQuery_FloatBlock | streamFieldInterfaceFields_pageQuery_DecimalBlock | streamFieldInterfaceFields_pageQuery_RegexBlock | streamFieldInterfaceFields_pageQuery_URLBlock | streamFieldInterfaceFields_pageQuery_BooleanBlock | streamFieldInterfaceFields_pageQuery_DateBlock | streamFieldInterfaceFields_pageQuery_TimeBlock | streamFieldInterfaceFields_pageQuery_DateTimeBlock | streamFieldInterfaceFields_pageQuery_RichTextBlock | streamFieldInterfaceFields_pageQuery_RawHTMLBlock | streamFieldInterfaceFields_pageQuery_BlockQuoteBlock | streamFieldInterfaceFields_pageQuery_ChoiceBlock | streamFieldInterfaceFields_pageQuery_StreamBlock | streamFieldInterfaceFields_pageQuery_StructBlock | streamFieldInterfaceFields_pageQuery_StaticBlock | streamFieldInterfaceFields_pageQuery_ListBlock | streamFieldInterfaceFields_pageQuery_EmbedBlock | streamFieldInterfaceFields_pageQuery_ImageGalleryImage | streamFieldInterfaceFields_pageQuery_ImageGalleryImages | streamFieldInterfaceFields_pageQuery_ImageGalleryBlock | streamFieldInterfaceFields_pageQuery_VideoBlock | streamFieldInterfaceFields_pageQuery_DocumentChooserBlock | streamFieldInterfaceFields_pageQuery_ImageChooserBlock | streamFieldInterfaceFields_pageQuery_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_pageQuery
// ====================================================

export interface streamFieldBlockFields_pageQuery {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_pageQuery
// ====================================================

export interface charBlockFields_pageQuery {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_pageQuery
// ====================================================

export interface textBlockFields_pageQuery {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_pageQuery
// ====================================================

export interface emailBlockFields_pageQuery {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_pageQuery
// ====================================================

export interface integerBlockFields_pageQuery {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_pageQuery
// ====================================================

export interface floatBlockFields_pageQuery {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_pageQuery
// ====================================================

export interface decimalBlockFields_pageQuery {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_pageQuery
// ====================================================

export interface regexBlockFields_pageQuery {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_pageQuery
// ====================================================

export interface uRLBlockFields_pageQuery {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_pageQuery
// ====================================================

export interface booleanBlockFields_pageQuery {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_pageQuery
// ====================================================

export interface dateBlockFields_pageQuery {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_pageQuery
// ====================================================

export interface timeBlockFields_pageQuery {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_pageQuery
// ====================================================

export interface dateTimeBlockFields_pageQuery {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_pageQuery
// ====================================================

export interface richTextBlockFields_pageQuery {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_pageQuery
// ====================================================

export interface rawHTMLBlockFields_pageQuery {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_pageQuery
// ====================================================

export interface blockQuoteBlockFields_pageQuery {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_pageQuery
// ====================================================

export interface choiceOptionFields_pageQuery {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_pageQuery
// ====================================================

export interface choiceBlockFields_pageQuery_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_pageQuery {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_pageQuery_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_pageQuery
// ====================================================

export interface streamBlockFields_pageQuery {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_pageQuery
// ====================================================

export interface structBlockFields_pageQuery {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_pageQuery
// ====================================================

export interface staticBlockFields_pageQuery {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_pageQuery
// ====================================================

export interface listBlockFields_pageQuery_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_pageQuery {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_pageQuery_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_pageQuery
// ====================================================

export interface embedBlockFields_pageQuery {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_pageQuery
// ====================================================

export interface imageGalleryImageFields_pageQuery {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_pageQuery
// ====================================================

export interface imageGalleryImagesFields_pageQuery {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_pageQuery
// ====================================================

export interface imageGalleryBlockFields_pageQuery {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_pageQuery
// ====================================================

export interface videoBlockFields_pageQuery {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_pageQuery
// ====================================================

export interface sNEKDocumentFields_pageQuery {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_pageQuery
// ====================================================

export interface documentChooserBlockFields_pageQuery_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_pageQuery {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_pageQuery_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_pageQuery
// ====================================================

export interface renditionFields_pageQuery_rendition {
  __typename: "Rendition";
}

export interface renditionFields_pageQuery {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_pageQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_pageQuery
// ====================================================

export interface sNEKImageFields_pageQuery_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_pageQuery {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_pageQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_pageQuery
// ====================================================

export interface imageChooserBlockFields_pageQuery_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_pageQuery {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_pageQuery_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_pageQuery
// ====================================================

export interface snippetChooserBlockFields_pageQuery {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageFields_pageQuery
// ====================================================

export interface studiePageFields_pageQuery_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface studiePageFields_pageQuery {
  __typename: "StudiePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  body: (studiePageFields_pageQuery_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: homePageFields_pageQuery
// ====================================================

export interface homePageFields_pageQuery_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface homePageFields_pageQuery {
  __typename: "HomePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  city: string;
  zipCode: string;
  address: string;
  telephone: string;
  telefax: string;
  vatNumber: string;
  whatsappTelephone: string;
  whatsappContactline: string;
  taxId: string;
  courtOfRegistry: string;
  placeOfRegistry: string;
  tradeRegisterNumber: string;
  ownership: string;
  email: string;
  copyrightholder: string;
  about: string;
  privacy: string;
  body: (homePageFields_pageQuery_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: userTypeFields_pageQuery
// ====================================================

export interface userTypeFields_pageQuery {
  __typename: "UserType";
  id: string;
  username: string | null;  // Required. 36 characters or fewer. Letters, digits and @/./+/-/_ only.
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: pageFields_pageQuery
// ====================================================

export interface pageFields_pageQuery_owner {
  __typename: "UserType";
}

export interface pageFields_pageQuery_lockedBy {
  __typename: "UserType";
}

export interface pageFields_pageQuery_aliasOf {
  __typename: "Page";
}

export interface pageFields_pageQuery_aliases {
  __typename: "Page";
}

export interface pageFields_pageQuery_homepage {
  __typename: "HomePage";
}

export interface pageFields_pageQuery_studiepage {
  __typename: "StudiePage";
}

export interface pageFields_pageQuery_studiepageindex {
  __typename: "StudiePageIndex";
}

export interface pageFields_pageQuery {
  __typename: "Page";
  id: string | null;
  path: string;
  depth: number | null;
  numchild: number;
  translationKey: any;
  title: string;
  draftTitle: string;
  slug: string;
  contentType: string;
  live: boolean;
  hasUnpublishedChanges: boolean;
  urlPath: string;
  owner: pageFields_pageQuery_owner | null;
  seoTitle: string;
  showInMenus: boolean;
  searchDescription: string;
  goLiveAt: any | null;
  expireAt: any | null;
  expired: boolean;
  locked: boolean;
  lockedAt: any | null;
  lockedBy: pageFields_pageQuery_lockedBy | null;
  firstPublishedAt: any | null;
  lastPublishedAt: any | null;
  latestRevisionCreatedAt: any | null;
  aliasOf: pageFields_pageQuery_aliasOf | null;
  aliases: pageFields_pageQuery_aliases[];
  homepage: pageFields_pageQuery_homepage | null;
  studiepage: pageFields_pageQuery_studiepage | null;
  studiepageindex: pageFields_pageQuery_studiepageindex | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: pageInterfaceFields_pagesQuery
// ====================================================

export interface pageInterfaceFields_pagesQuery_StudiePageIndex {
  __typename: "StudiePageIndex";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pagesQuery_StudiePage {
  __typename: "StudiePage";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pagesQuery_HomePage {
  __typename: "HomePage";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pagesQuery_Page {
  __typename: "Page";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export type pageInterfaceFields_pagesQuery = pageInterfaceFields_pagesQuery_StudiePageIndex | pageInterfaceFields_pagesQuery_StudiePage | pageInterfaceFields_pagesQuery_HomePage | pageInterfaceFields_pagesQuery_Page;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageIndexFields_pagesQuery
// ====================================================

export interface studiePageIndexFields_pagesQuery {
  __typename: "StudiePageIndex";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_pagesQuery
// ====================================================

export interface streamFieldInterfaceFields_pagesQuery_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pagesQuery_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_pagesQuery = streamFieldInterfaceFields_pagesQuery_StreamFieldBlock | streamFieldInterfaceFields_pagesQuery_CharBlock | streamFieldInterfaceFields_pagesQuery_TextBlock | streamFieldInterfaceFields_pagesQuery_EmailBlock | streamFieldInterfaceFields_pagesQuery_IntegerBlock | streamFieldInterfaceFields_pagesQuery_FloatBlock | streamFieldInterfaceFields_pagesQuery_DecimalBlock | streamFieldInterfaceFields_pagesQuery_RegexBlock | streamFieldInterfaceFields_pagesQuery_URLBlock | streamFieldInterfaceFields_pagesQuery_BooleanBlock | streamFieldInterfaceFields_pagesQuery_DateBlock | streamFieldInterfaceFields_pagesQuery_TimeBlock | streamFieldInterfaceFields_pagesQuery_DateTimeBlock | streamFieldInterfaceFields_pagesQuery_RichTextBlock | streamFieldInterfaceFields_pagesQuery_RawHTMLBlock | streamFieldInterfaceFields_pagesQuery_BlockQuoteBlock | streamFieldInterfaceFields_pagesQuery_ChoiceBlock | streamFieldInterfaceFields_pagesQuery_StreamBlock | streamFieldInterfaceFields_pagesQuery_StructBlock | streamFieldInterfaceFields_pagesQuery_StaticBlock | streamFieldInterfaceFields_pagesQuery_ListBlock | streamFieldInterfaceFields_pagesQuery_EmbedBlock | streamFieldInterfaceFields_pagesQuery_ImageGalleryImage | streamFieldInterfaceFields_pagesQuery_ImageGalleryImages | streamFieldInterfaceFields_pagesQuery_ImageGalleryBlock | streamFieldInterfaceFields_pagesQuery_VideoBlock | streamFieldInterfaceFields_pagesQuery_DocumentChooserBlock | streamFieldInterfaceFields_pagesQuery_ImageChooserBlock | streamFieldInterfaceFields_pagesQuery_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_pagesQuery
// ====================================================

export interface streamFieldBlockFields_pagesQuery {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_pagesQuery
// ====================================================

export interface charBlockFields_pagesQuery {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_pagesQuery
// ====================================================

export interface textBlockFields_pagesQuery {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_pagesQuery
// ====================================================

export interface emailBlockFields_pagesQuery {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_pagesQuery
// ====================================================

export interface integerBlockFields_pagesQuery {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_pagesQuery
// ====================================================

export interface floatBlockFields_pagesQuery {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_pagesQuery
// ====================================================

export interface decimalBlockFields_pagesQuery {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_pagesQuery
// ====================================================

export interface regexBlockFields_pagesQuery {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_pagesQuery
// ====================================================

export interface uRLBlockFields_pagesQuery {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_pagesQuery
// ====================================================

export interface booleanBlockFields_pagesQuery {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_pagesQuery
// ====================================================

export interface dateBlockFields_pagesQuery {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_pagesQuery
// ====================================================

export interface timeBlockFields_pagesQuery {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_pagesQuery
// ====================================================

export interface dateTimeBlockFields_pagesQuery {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_pagesQuery
// ====================================================

export interface richTextBlockFields_pagesQuery {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_pagesQuery
// ====================================================

export interface rawHTMLBlockFields_pagesQuery {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_pagesQuery
// ====================================================

export interface blockQuoteBlockFields_pagesQuery {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_pagesQuery
// ====================================================

export interface choiceOptionFields_pagesQuery {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_pagesQuery
// ====================================================

export interface choiceBlockFields_pagesQuery_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_pagesQuery {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_pagesQuery_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_pagesQuery
// ====================================================

export interface streamBlockFields_pagesQuery {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_pagesQuery
// ====================================================

export interface structBlockFields_pagesQuery {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_pagesQuery
// ====================================================

export interface staticBlockFields_pagesQuery {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_pagesQuery
// ====================================================

export interface listBlockFields_pagesQuery_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_pagesQuery {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_pagesQuery_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_pagesQuery
// ====================================================

export interface embedBlockFields_pagesQuery {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_pagesQuery
// ====================================================

export interface imageGalleryImageFields_pagesQuery {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_pagesQuery
// ====================================================

export interface imageGalleryImagesFields_pagesQuery {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_pagesQuery
// ====================================================

export interface imageGalleryBlockFields_pagesQuery {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_pagesQuery
// ====================================================

export interface videoBlockFields_pagesQuery {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_pagesQuery
// ====================================================

export interface sNEKDocumentFields_pagesQuery {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_pagesQuery
// ====================================================

export interface documentChooserBlockFields_pagesQuery_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_pagesQuery {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_pagesQuery_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_pagesQuery
// ====================================================

export interface renditionFields_pagesQuery_rendition {
  __typename: "Rendition";
}

export interface renditionFields_pagesQuery {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_pagesQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_pagesQuery
// ====================================================

export interface sNEKImageFields_pagesQuery_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_pagesQuery {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_pagesQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_pagesQuery
// ====================================================

export interface imageChooserBlockFields_pagesQuery_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_pagesQuery {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_pagesQuery_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_pagesQuery
// ====================================================

export interface snippetChooserBlockFields_pagesQuery {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageFields_pagesQuery
// ====================================================

export interface studiePageFields_pagesQuery_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface studiePageFields_pagesQuery {
  __typename: "StudiePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  body: (studiePageFields_pagesQuery_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: homePageFields_pagesQuery
// ====================================================

export interface homePageFields_pagesQuery_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface homePageFields_pagesQuery {
  __typename: "HomePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  city: string;
  zipCode: string;
  address: string;
  telephone: string;
  telefax: string;
  vatNumber: string;
  whatsappTelephone: string;
  whatsappContactline: string;
  taxId: string;
  courtOfRegistry: string;
  placeOfRegistry: string;
  tradeRegisterNumber: string;
  ownership: string;
  email: string;
  copyrightholder: string;
  about: string;
  privacy: string;
  body: (homePageFields_pagesQuery_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: userTypeFields_pagesQuery
// ====================================================

export interface userTypeFields_pagesQuery {
  __typename: "UserType";
  id: string;
  username: string | null;  // Required. 36 characters or fewer. Letters, digits and @/./+/-/_ only.
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: pageFields_pagesQuery
// ====================================================

export interface pageFields_pagesQuery_owner {
  __typename: "UserType";
}

export interface pageFields_pagesQuery_lockedBy {
  __typename: "UserType";
}

export interface pageFields_pagesQuery_aliasOf {
  __typename: "Page";
}

export interface pageFields_pagesQuery_aliases {
  __typename: "Page";
}

export interface pageFields_pagesQuery_homepage {
  __typename: "HomePage";
}

export interface pageFields_pagesQuery_studiepage {
  __typename: "StudiePage";
}

export interface pageFields_pagesQuery_studiepageindex {
  __typename: "StudiePageIndex";
}

export interface pageFields_pagesQuery {
  __typename: "Page";
  id: string | null;
  path: string;
  depth: number | null;
  numchild: number;
  translationKey: any;
  title: string;
  draftTitle: string;
  slug: string;
  contentType: string;
  live: boolean;
  hasUnpublishedChanges: boolean;
  urlPath: string;
  owner: pageFields_pagesQuery_owner | null;
  seoTitle: string;
  showInMenus: boolean;
  searchDescription: string;
  goLiveAt: any | null;
  expireAt: any | null;
  expired: boolean;
  locked: boolean;
  lockedAt: any | null;
  lockedBy: pageFields_pagesQuery_lockedBy | null;
  firstPublishedAt: any | null;
  lastPublishedAt: any | null;
  latestRevisionCreatedAt: any | null;
  aliasOf: pageFields_pagesQuery_aliasOf | null;
  aliases: pageFields_pagesQuery_aliases[];
  homepage: pageFields_pagesQuery_homepage | null;
  studiepage: pageFields_pagesQuery_studiepage | null;
  studiepageindex: pageFields_pagesQuery_studiepageindex | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_readHomePageQuery
// ====================================================

export interface streamFieldInterfaceFields_readHomePageQuery_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readHomePageQuery_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_readHomePageQuery = streamFieldInterfaceFields_readHomePageQuery_StreamFieldBlock | streamFieldInterfaceFields_readHomePageQuery_CharBlock | streamFieldInterfaceFields_readHomePageQuery_TextBlock | streamFieldInterfaceFields_readHomePageQuery_EmailBlock | streamFieldInterfaceFields_readHomePageQuery_IntegerBlock | streamFieldInterfaceFields_readHomePageQuery_FloatBlock | streamFieldInterfaceFields_readHomePageQuery_DecimalBlock | streamFieldInterfaceFields_readHomePageQuery_RegexBlock | streamFieldInterfaceFields_readHomePageQuery_URLBlock | streamFieldInterfaceFields_readHomePageQuery_BooleanBlock | streamFieldInterfaceFields_readHomePageQuery_DateBlock | streamFieldInterfaceFields_readHomePageQuery_TimeBlock | streamFieldInterfaceFields_readHomePageQuery_DateTimeBlock | streamFieldInterfaceFields_readHomePageQuery_RichTextBlock | streamFieldInterfaceFields_readHomePageQuery_RawHTMLBlock | streamFieldInterfaceFields_readHomePageQuery_BlockQuoteBlock | streamFieldInterfaceFields_readHomePageQuery_ChoiceBlock | streamFieldInterfaceFields_readHomePageQuery_StreamBlock | streamFieldInterfaceFields_readHomePageQuery_StructBlock | streamFieldInterfaceFields_readHomePageQuery_StaticBlock | streamFieldInterfaceFields_readHomePageQuery_ListBlock | streamFieldInterfaceFields_readHomePageQuery_EmbedBlock | streamFieldInterfaceFields_readHomePageQuery_ImageGalleryImage | streamFieldInterfaceFields_readHomePageQuery_ImageGalleryImages | streamFieldInterfaceFields_readHomePageQuery_ImageGalleryBlock | streamFieldInterfaceFields_readHomePageQuery_VideoBlock | streamFieldInterfaceFields_readHomePageQuery_DocumentChooserBlock | streamFieldInterfaceFields_readHomePageQuery_ImageChooserBlock | streamFieldInterfaceFields_readHomePageQuery_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_readHomePageQuery
// ====================================================

export interface streamFieldBlockFields_readHomePageQuery {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_readHomePageQuery
// ====================================================

export interface charBlockFields_readHomePageQuery {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_readHomePageQuery
// ====================================================

export interface textBlockFields_readHomePageQuery {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_readHomePageQuery
// ====================================================

export interface emailBlockFields_readHomePageQuery {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_readHomePageQuery
// ====================================================

export interface integerBlockFields_readHomePageQuery {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_readHomePageQuery
// ====================================================

export interface floatBlockFields_readHomePageQuery {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_readHomePageQuery
// ====================================================

export interface decimalBlockFields_readHomePageQuery {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_readHomePageQuery
// ====================================================

export interface regexBlockFields_readHomePageQuery {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_readHomePageQuery
// ====================================================

export interface uRLBlockFields_readHomePageQuery {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_readHomePageQuery
// ====================================================

export interface booleanBlockFields_readHomePageQuery {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_readHomePageQuery
// ====================================================

export interface dateBlockFields_readHomePageQuery {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_readHomePageQuery
// ====================================================

export interface timeBlockFields_readHomePageQuery {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_readHomePageQuery
// ====================================================

export interface dateTimeBlockFields_readHomePageQuery {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_readHomePageQuery
// ====================================================

export interface richTextBlockFields_readHomePageQuery {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_readHomePageQuery
// ====================================================

export interface rawHTMLBlockFields_readHomePageQuery {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_readHomePageQuery
// ====================================================

export interface blockQuoteBlockFields_readHomePageQuery {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_readHomePageQuery
// ====================================================

export interface choiceOptionFields_readHomePageQuery {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_readHomePageQuery
// ====================================================

export interface choiceBlockFields_readHomePageQuery_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_readHomePageQuery {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_readHomePageQuery_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_readHomePageQuery
// ====================================================

export interface streamBlockFields_readHomePageQuery {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_readHomePageQuery
// ====================================================

export interface structBlockFields_readHomePageQuery {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_readHomePageQuery
// ====================================================

export interface staticBlockFields_readHomePageQuery {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_readHomePageQuery
// ====================================================

export interface listBlockFields_readHomePageQuery_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_readHomePageQuery {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_readHomePageQuery_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_readHomePageQuery
// ====================================================

export interface embedBlockFields_readHomePageQuery {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_readHomePageQuery
// ====================================================

export interface imageGalleryImageFields_readHomePageQuery {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_readHomePageQuery
// ====================================================

export interface imageGalleryImagesFields_readHomePageQuery {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_readHomePageQuery
// ====================================================

export interface imageGalleryBlockFields_readHomePageQuery {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_readHomePageQuery
// ====================================================

export interface videoBlockFields_readHomePageQuery {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_readHomePageQuery
// ====================================================

export interface sNEKDocumentFields_readHomePageQuery {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_readHomePageQuery
// ====================================================

export interface documentChooserBlockFields_readHomePageQuery_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_readHomePageQuery {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_readHomePageQuery_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_readHomePageQuery
// ====================================================

export interface renditionFields_readHomePageQuery_rendition {
  __typename: "Rendition";
}

export interface renditionFields_readHomePageQuery {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_readHomePageQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_readHomePageQuery
// ====================================================

export interface sNEKImageFields_readHomePageQuery_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_readHomePageQuery {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_readHomePageQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_readHomePageQuery
// ====================================================

export interface imageChooserBlockFields_readHomePageQuery_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_readHomePageQuery {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_readHomePageQuery_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_readHomePageQuery
// ====================================================

export interface snippetChooserBlockFields_readHomePageQuery {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: homePageFields_readHomePageQuery
// ====================================================

export interface homePageFields_readHomePageQuery_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface homePageFields_readHomePageQuery {
  __typename: "HomePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  city: string;
  zipCode: string;
  address: string;
  telephone: string;
  telefax: string;
  vatNumber: string;
  whatsappTelephone: string;
  whatsappContactline: string;
  taxId: string;
  courtOfRegistry: string;
  placeOfRegistry: string;
  tradeRegisterNumber: string;
  ownership: string;
  email: string;
  copyrightholder: string;
  about: string;
  privacy: string;
  body: (homePageFields_readHomePageQuery_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: socialMediaSettingsFields_readSocialMediaSettingsQuery
// ====================================================

export interface socialMediaSettingsFields_readSocialMediaSettingsQuery {
  __typename: "SocialMediaSettings";
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_readStudiePageQuery
// ====================================================

export interface streamFieldInterfaceFields_readStudiePageQuery_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_readStudiePageQuery_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_readStudiePageQuery = streamFieldInterfaceFields_readStudiePageQuery_StreamFieldBlock | streamFieldInterfaceFields_readStudiePageQuery_CharBlock | streamFieldInterfaceFields_readStudiePageQuery_TextBlock | streamFieldInterfaceFields_readStudiePageQuery_EmailBlock | streamFieldInterfaceFields_readStudiePageQuery_IntegerBlock | streamFieldInterfaceFields_readStudiePageQuery_FloatBlock | streamFieldInterfaceFields_readStudiePageQuery_DecimalBlock | streamFieldInterfaceFields_readStudiePageQuery_RegexBlock | streamFieldInterfaceFields_readStudiePageQuery_URLBlock | streamFieldInterfaceFields_readStudiePageQuery_BooleanBlock | streamFieldInterfaceFields_readStudiePageQuery_DateBlock | streamFieldInterfaceFields_readStudiePageQuery_TimeBlock | streamFieldInterfaceFields_readStudiePageQuery_DateTimeBlock | streamFieldInterfaceFields_readStudiePageQuery_RichTextBlock | streamFieldInterfaceFields_readStudiePageQuery_RawHTMLBlock | streamFieldInterfaceFields_readStudiePageQuery_BlockQuoteBlock | streamFieldInterfaceFields_readStudiePageQuery_ChoiceBlock | streamFieldInterfaceFields_readStudiePageQuery_StreamBlock | streamFieldInterfaceFields_readStudiePageQuery_StructBlock | streamFieldInterfaceFields_readStudiePageQuery_StaticBlock | streamFieldInterfaceFields_readStudiePageQuery_ListBlock | streamFieldInterfaceFields_readStudiePageQuery_EmbedBlock | streamFieldInterfaceFields_readStudiePageQuery_ImageGalleryImage | streamFieldInterfaceFields_readStudiePageQuery_ImageGalleryImages | streamFieldInterfaceFields_readStudiePageQuery_ImageGalleryBlock | streamFieldInterfaceFields_readStudiePageQuery_VideoBlock | streamFieldInterfaceFields_readStudiePageQuery_DocumentChooserBlock | streamFieldInterfaceFields_readStudiePageQuery_ImageChooserBlock | streamFieldInterfaceFields_readStudiePageQuery_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_readStudiePageQuery
// ====================================================

export interface streamFieldBlockFields_readStudiePageQuery {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_readStudiePageQuery
// ====================================================

export interface charBlockFields_readStudiePageQuery {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_readStudiePageQuery
// ====================================================

export interface textBlockFields_readStudiePageQuery {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_readStudiePageQuery
// ====================================================

export interface emailBlockFields_readStudiePageQuery {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_readStudiePageQuery
// ====================================================

export interface integerBlockFields_readStudiePageQuery {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_readStudiePageQuery
// ====================================================

export interface floatBlockFields_readStudiePageQuery {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_readStudiePageQuery
// ====================================================

export interface decimalBlockFields_readStudiePageQuery {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_readStudiePageQuery
// ====================================================

export interface regexBlockFields_readStudiePageQuery {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_readStudiePageQuery
// ====================================================

export interface uRLBlockFields_readStudiePageQuery {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_readStudiePageQuery
// ====================================================

export interface booleanBlockFields_readStudiePageQuery {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_readStudiePageQuery
// ====================================================

export interface dateBlockFields_readStudiePageQuery {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_readStudiePageQuery
// ====================================================

export interface timeBlockFields_readStudiePageQuery {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_readStudiePageQuery
// ====================================================

export interface dateTimeBlockFields_readStudiePageQuery {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_readStudiePageQuery
// ====================================================

export interface richTextBlockFields_readStudiePageQuery {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_readStudiePageQuery
// ====================================================

export interface rawHTMLBlockFields_readStudiePageQuery {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_readStudiePageQuery
// ====================================================

export interface blockQuoteBlockFields_readStudiePageQuery {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_readStudiePageQuery
// ====================================================

export interface choiceOptionFields_readStudiePageQuery {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_readStudiePageQuery
// ====================================================

export interface choiceBlockFields_readStudiePageQuery_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_readStudiePageQuery {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_readStudiePageQuery_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_readStudiePageQuery
// ====================================================

export interface streamBlockFields_readStudiePageQuery {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_readStudiePageQuery
// ====================================================

export interface structBlockFields_readStudiePageQuery {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_readStudiePageQuery
// ====================================================

export interface staticBlockFields_readStudiePageQuery {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_readStudiePageQuery
// ====================================================

export interface listBlockFields_readStudiePageQuery_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_readStudiePageQuery {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_readStudiePageQuery_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_readStudiePageQuery
// ====================================================

export interface embedBlockFields_readStudiePageQuery {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_readStudiePageQuery
// ====================================================

export interface imageGalleryImageFields_readStudiePageQuery {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_readStudiePageQuery
// ====================================================

export interface imageGalleryImagesFields_readStudiePageQuery {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_readStudiePageQuery
// ====================================================

export interface imageGalleryBlockFields_readStudiePageQuery {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_readStudiePageQuery
// ====================================================

export interface videoBlockFields_readStudiePageQuery {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_readStudiePageQuery
// ====================================================

export interface sNEKDocumentFields_readStudiePageQuery {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_readStudiePageQuery
// ====================================================

export interface documentChooserBlockFields_readStudiePageQuery_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_readStudiePageQuery {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_readStudiePageQuery_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_readStudiePageQuery
// ====================================================

export interface renditionFields_readStudiePageQuery_rendition {
  __typename: "Rendition";
}

export interface renditionFields_readStudiePageQuery {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_readStudiePageQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_readStudiePageQuery
// ====================================================

export interface sNEKImageFields_readStudiePageQuery_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_readStudiePageQuery {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_readStudiePageQuery_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_readStudiePageQuery
// ====================================================

export interface imageChooserBlockFields_readStudiePageQuery_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_readStudiePageQuery {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_readStudiePageQuery_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_readStudiePageQuery
// ====================================================

export interface snippetChooserBlockFields_readStudiePageQuery {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageFields_readStudiePageQuery
// ====================================================

export interface studiePageFields_readStudiePageQuery_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface studiePageFields_readStudiePageQuery {
  __typename: "StudiePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  body: (studiePageFields_readStudiePageQuery_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageIndexFields_readStudiePageIndexQuery
// ====================================================

export interface studiePageIndexFields_readStudiePageIndexQuery {
  __typename: "StudiePageIndex";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: pageInterfaceFields_pageSubscription
// ====================================================

export interface pageInterfaceFields_pageSubscription_StudiePageIndex {
  __typename: "StudiePageIndex";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pageSubscription_StudiePage {
  __typename: "StudiePage";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pageSubscription_HomePage {
  __typename: "HomePage";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export interface pageInterfaceFields_pageSubscription_Page {
  __typename: "Page";
  id: string | null;
  url: string | null;
  urlPath: string;
  slug: string;
  depth: number | null;
  pageType: string | null;
  title: string;
  seoTitle: string;
  seoDescription: string | null;
  showInMenus: boolean;
  contentType: string;
  lastPublishedAt: any | null;
}

export type pageInterfaceFields_pageSubscription = pageInterfaceFields_pageSubscription_StudiePageIndex | pageInterfaceFields_pageSubscription_StudiePage | pageInterfaceFields_pageSubscription_HomePage | pageInterfaceFields_pageSubscription_Page;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageIndexFields_pageSubscription
// ====================================================

export interface studiePageIndexFields_pageSubscription {
  __typename: "StudiePageIndex";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldInterfaceFields_pageSubscription
// ====================================================

export interface streamFieldInterfaceFields_pageSubscription_StreamFieldBlock {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_CharBlock {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_TextBlock {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_EmailBlock {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_IntegerBlock {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_FloatBlock {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_DecimalBlock {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_RegexBlock {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_URLBlock {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_BooleanBlock {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_DateBlock {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_TimeBlock {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_DateTimeBlock {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_RichTextBlock {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_RawHTMLBlock {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_BlockQuoteBlock {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_ChoiceBlock {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_StreamBlock {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_StructBlock {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_StaticBlock {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_ListBlock {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_EmbedBlock {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_ImageGalleryImage {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_ImageGalleryImages {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_ImageGalleryBlock {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_VideoBlock {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_DocumentChooserBlock {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_ImageChooserBlock {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export interface streamFieldInterfaceFields_pageSubscription_SnippetChooserBlock {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}

export type streamFieldInterfaceFields_pageSubscription = streamFieldInterfaceFields_pageSubscription_StreamFieldBlock | streamFieldInterfaceFields_pageSubscription_CharBlock | streamFieldInterfaceFields_pageSubscription_TextBlock | streamFieldInterfaceFields_pageSubscription_EmailBlock | streamFieldInterfaceFields_pageSubscription_IntegerBlock | streamFieldInterfaceFields_pageSubscription_FloatBlock | streamFieldInterfaceFields_pageSubscription_DecimalBlock | streamFieldInterfaceFields_pageSubscription_RegexBlock | streamFieldInterfaceFields_pageSubscription_URLBlock | streamFieldInterfaceFields_pageSubscription_BooleanBlock | streamFieldInterfaceFields_pageSubscription_DateBlock | streamFieldInterfaceFields_pageSubscription_TimeBlock | streamFieldInterfaceFields_pageSubscription_DateTimeBlock | streamFieldInterfaceFields_pageSubscription_RichTextBlock | streamFieldInterfaceFields_pageSubscription_RawHTMLBlock | streamFieldInterfaceFields_pageSubscription_BlockQuoteBlock | streamFieldInterfaceFields_pageSubscription_ChoiceBlock | streamFieldInterfaceFields_pageSubscription_StreamBlock | streamFieldInterfaceFields_pageSubscription_StructBlock | streamFieldInterfaceFields_pageSubscription_StaticBlock | streamFieldInterfaceFields_pageSubscription_ListBlock | streamFieldInterfaceFields_pageSubscription_EmbedBlock | streamFieldInterfaceFields_pageSubscription_ImageGalleryImage | streamFieldInterfaceFields_pageSubscription_ImageGalleryImages | streamFieldInterfaceFields_pageSubscription_ImageGalleryBlock | streamFieldInterfaceFields_pageSubscription_VideoBlock | streamFieldInterfaceFields_pageSubscription_DocumentChooserBlock | streamFieldInterfaceFields_pageSubscription_ImageChooserBlock | streamFieldInterfaceFields_pageSubscription_SnippetChooserBlock;


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamFieldBlockFields_pageSubscription
// ====================================================

export interface streamFieldBlockFields_pageSubscription {
  __typename: "StreamFieldBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: charBlockFields_pageSubscription
// ====================================================

export interface charBlockFields_pageSubscription {
  __typename: "CharBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: textBlockFields_pageSubscription
// ====================================================

export interface textBlockFields_pageSubscription {
  __typename: "TextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: emailBlockFields_pageSubscription
// ====================================================

export interface emailBlockFields_pageSubscription {
  __typename: "EmailBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: integerBlockFields_pageSubscription
// ====================================================

export interface integerBlockFields_pageSubscription {
  __typename: "IntegerBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: floatBlockFields_pageSubscription
// ====================================================

export interface floatBlockFields_pageSubscription {
  __typename: "FloatBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: decimalBlockFields_pageSubscription
// ====================================================

export interface decimalBlockFields_pageSubscription {
  __typename: "DecimalBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: regexBlockFields_pageSubscription
// ====================================================

export interface regexBlockFields_pageSubscription {
  __typename: "RegexBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: uRLBlockFields_pageSubscription
// ====================================================

export interface uRLBlockFields_pageSubscription {
  __typename: "URLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: booleanBlockFields_pageSubscription
// ====================================================

export interface booleanBlockFields_pageSubscription {
  __typename: "BooleanBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateBlockFields_pageSubscription
// ====================================================

export interface dateBlockFields_pageSubscription {
  __typename: "DateBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: timeBlockFields_pageSubscription
// ====================================================

export interface timeBlockFields_pageSubscription {
  __typename: "TimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: dateTimeBlockFields_pageSubscription
// ====================================================

export interface dateTimeBlockFields_pageSubscription {
  __typename: "DateTimeBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: richTextBlockFields_pageSubscription
// ====================================================

export interface richTextBlockFields_pageSubscription {
  __typename: "RichTextBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: rawHTMLBlockFields_pageSubscription
// ====================================================

export interface rawHTMLBlockFields_pageSubscription {
  __typename: "RawHTMLBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: blockQuoteBlockFields_pageSubscription
// ====================================================

export interface blockQuoteBlockFields_pageSubscription {
  __typename: "BlockQuoteBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceOptionFields_pageSubscription
// ====================================================

export interface choiceOptionFields_pageSubscription {
  __typename: "ChoiceOption";
  key: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: choiceBlockFields_pageSubscription
// ====================================================

export interface choiceBlockFields_pageSubscription_choices {
  __typename: "ChoiceOption";
}

export interface choiceBlockFields_pageSubscription {
  __typename: "ChoiceBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  choices: choiceBlockFields_pageSubscription_choices[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: streamBlockFields_pageSubscription
// ====================================================

export interface streamBlockFields_pageSubscription {
  __typename: "StreamBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: structBlockFields_pageSubscription
// ====================================================

export interface structBlockFields_pageSubscription {
  __typename: "StructBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: staticBlockFields_pageSubscription
// ====================================================

export interface staticBlockFields_pageSubscription {
  __typename: "StaticBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: listBlockFields_pageSubscription
// ====================================================

export interface listBlockFields_pageSubscription_items {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface listBlockFields_pageSubscription {
  __typename: "ListBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  items: listBlockFields_pageSubscription_items[];
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: embedBlockFields_pageSubscription
// ====================================================

export interface embedBlockFields_pageSubscription {
  __typename: "EmbedBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  value: string;
  url: string;
  embed: string | null;
  rawEmbed: any | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImageFields_pageSubscription
// ====================================================

export interface imageGalleryImageFields_pageSubscription {
  __typename: "ImageGalleryImage";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryImagesFields_pageSubscription
// ====================================================

export interface imageGalleryImagesFields_pageSubscription {
  __typename: "ImageGalleryImages";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageGalleryBlockFields_pageSubscription
// ====================================================

export interface imageGalleryBlockFields_pageSubscription {
  __typename: "ImageGalleryBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: videoBlockFields_pageSubscription
// ====================================================

export interface videoBlockFields_pageSubscription {
  __typename: "VideoBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKDocumentFields_pageSubscription
// ====================================================

export interface sNEKDocumentFields_pageSubscription {
  __typename: "SNEKDocument";
  title: string;
  file: string;
  createdAt: any;
  fileSize: number | null;
  fileHash: string | null;
  id: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: documentChooserBlockFields_pageSubscription
// ====================================================

export interface documentChooserBlockFields_pageSubscription_document {
  __typename: "SNEKDocument";
}

export interface documentChooserBlockFields_pageSubscription {
  __typename: "DocumentChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  document: documentChooserBlockFields_pageSubscription_document;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: renditionFields_pageSubscription
// ====================================================

export interface renditionFields_pageSubscription_rendition {
  __typename: "Rendition";
}

export interface renditionFields_pageSubscription {
  __typename: "Rendition";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: renditionFields_pageSubscription_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: sNEKImageFields_pageSubscription
// ====================================================

export interface sNEKImageFields_pageSubscription_rendition {
  __typename: "Rendition";
}

export interface sNEKImageFields_pageSubscription {
  __typename: "SNEKImage";
  width: number;
  height: number;
  id: string | null;
  src: string;
  aspectRatio: number;
  sizes: string;
  rendition: sNEKImageFields_pageSubscription_rendition | null;
  srcSet: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: imageChooserBlockFields_pageSubscription
// ====================================================

export interface imageChooserBlockFields_pageSubscription_image {
  __typename: "SNEKImage";
}

export interface imageChooserBlockFields_pageSubscription {
  __typename: "ImageChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  image: imageChooserBlockFields_pageSubscription_image;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: snippetChooserBlockFields_pageSubscription
// ====================================================

export interface snippetChooserBlockFields_pageSubscription {
  __typename: "SnippetChooserBlock";
  id: string | null;
  blockType: string;
  field: string;
  rawValue: string;
  snippet: string;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: studiePageFields_pageSubscription
// ====================================================

export interface studiePageFields_pageSubscription_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface studiePageFields_pageSubscription {
  __typename: "StudiePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  body: (studiePageFields_pageSubscription_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: homePageFields_pageSubscription
// ====================================================

export interface homePageFields_pageSubscription_body {
  __typename: "StreamFieldBlock" | "CharBlock" | "TextBlock" | "EmailBlock" | "IntegerBlock" | "FloatBlock" | "DecimalBlock" | "RegexBlock" | "URLBlock" | "BooleanBlock" | "DateBlock" | "TimeBlock" | "DateTimeBlock" | "RichTextBlock" | "RawHTMLBlock" | "BlockQuoteBlock" | "ChoiceBlock" | "StreamBlock" | "StructBlock" | "StaticBlock" | "ListBlock" | "EmbedBlock" | "ImageGalleryImage" | "ImageGalleryImages" | "ImageGalleryBlock" | "VideoBlock" | "DocumentChooserBlock" | "ImageChooserBlock" | "SnippetChooserBlock";
}

export interface homePageFields_pageSubscription {
  __typename: "HomePage";
  id: string | null;
  depth: number | null;
  title: string;
  slug: string;
  contentType: string;
  urlPath: string;
  seoTitle: string;
  showInMenus: boolean;
  lastPublishedAt: any | null;
  city: string;
  zipCode: string;
  address: string;
  telephone: string;
  telefax: string;
  vatNumber: string;
  whatsappTelephone: string;
  whatsappContactline: string;
  taxId: string;
  courtOfRegistry: string;
  placeOfRegistry: string;
  tradeRegisterNumber: string;
  ownership: string;
  email: string;
  copyrightholder: string;
  about: string;
  privacy: string;
  body: (homePageFields_pageSubscription_body | null)[] | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: userTypeFields_pageSubscription
// ====================================================

export interface userTypeFields_pageSubscription {
  __typename: "UserType";
  id: string;
  username: string | null;  // Required. 36 characters or fewer. Letters, digits and @/./+/-/_ only.
}


/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: pageFields_pageSubscription
// ====================================================

export interface pageFields_pageSubscription_owner {
  __typename: "UserType";
}

export interface pageFields_pageSubscription_lockedBy {
  __typename: "UserType";
}

export interface pageFields_pageSubscription_aliasOf {
  __typename: "Page";
}

export interface pageFields_pageSubscription_aliases {
  __typename: "Page";
}

export interface pageFields_pageSubscription_homepage {
  __typename: "HomePage";
}

export interface pageFields_pageSubscription_studiepage {
  __typename: "StudiePage";
}

export interface pageFields_pageSubscription_studiepageindex {
  __typename: "StudiePageIndex";
}

export interface pageFields_pageSubscription {
  __typename: "Page";
  id: string | null;
  path: string;
  depth: number | null;
  numchild: number;
  translationKey: any;
  title: string;
  draftTitle: string;
  slug: string;
  contentType: string;
  live: boolean;
  hasUnpublishedChanges: boolean;
  urlPath: string;
  owner: pageFields_pageSubscription_owner | null;
  seoTitle: string;
  showInMenus: boolean;
  searchDescription: string;
  goLiveAt: any | null;
  expireAt: any | null;
  expired: boolean;
  locked: boolean;
  lockedAt: any | null;
  lockedBy: pageFields_pageSubscription_lockedBy | null;
  firstPublishedAt: any | null;
  lastPublishedAt: any | null;
  latestRevisionCreatedAt: any | null;
  aliasOf: pageFields_pageSubscription_aliasOf | null;
  aliases: pageFields_pageSubscription_aliases[];
  homepage: pageFields_pageSubscription_homepage | null;
  studiepage: pageFields_pageSubscription_studiepage | null;
  studiepageindex: pageFields_pageSubscription_studiepageindex | null;
  url: string | null;
  pageType: string | null;
  seoDescription: string | null;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

//==============================================================
// START Enums and Input Objects
//==============================================================

// null
export interface CreateHomePageInput {
  slug?: string | null;
  title?: string | null;
  city?: string | null;
  zipCode?: string | null;
  address?: string | null;
  telephone?: string | null;
  telefax?: string | null;
  vatNumber?: string | null;
  whatsappTelephone?: string | null;
  whatsappContactline?: string | null;
  taxId?: string | null;
  tradeRegisterNumber?: string | null;
  courtOfRegistry?: string | null;
  placeOfRegistry?: string | null;
  ownership?: string | null;
  email?: string | null;
  copyrightholder?: string | null;
  about?: string | null;
  privacy?: string | null;
  body?: any | null;
  parentPage?: string | null;
}

// null
export interface DeleteHomePageInput {
  title?: string | null;
  id?: string | null;
}

// null
export interface DeleteSocialMediaSettingsInput {
  id?: string | null;
}

// null
export interface DeleteStudiePageInput {
  id?: string | null;
}

// null
export interface DeleteStudiePageIndexInput {
  id?: string | null;
}

// null
export interface UpdateHomePageInput {
  slug?: string | null;
  title?: string | null;
  city?: string | null;
  zipCode?: string | null;
  address?: string | null;
  telephone?: string | null;
  telefax?: string | null;
  vatNumber?: string | null;
  whatsappTelephone?: string | null;
  whatsappContactline?: string | null;
  taxId?: string | null;
  tradeRegisterNumber?: string | null;
  courtOfRegistry?: string | null;
  placeOfRegistry?: string | null;
  ownership?: string | null;
  email?: string | null;
  copyrightholder?: string | null;
  about?: string | null;
  privacy?: string | null;
  body?: any | null;
}

//==============================================================
// END Enums and Input Objects
//==============================================================