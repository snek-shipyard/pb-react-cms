
/**
 * @license
 * Copyright Nico Schett. All Rights Reserved.
 */

/* tslint:disable */
// This file was automatically generated and should not be edited.

import { GraphqlResult } from "bridge/lib/types";
import gql from "graphql-tag";

import BridgeDrop from "./index";

// @ts-ignore
import { deleteStudiePageIndexMutation,deleteStudiePageIndexMutationVariables,deleteStudiePageMutation,deleteStudiePageMutationVariables,deleteHomePageMutation,deleteHomePageMutationVariables,updateHomePageMutation,updateHomePageMutationVariables,createHomePageMutation,createHomePageMutationVariables,deleteSocialMediaSettingsMutation,deleteSocialMediaSettingsMutationVariables,tokenAuthMutation,tokenAuthMutationVariables,verifyTokenMutation,verifyTokenMutationVariables,refreshTokenMutation,refreshTokenMutationVariables,revokeTokenMutation,revokeTokenMutationVariables } from "./types.gen";

// ====================================================
// Bridge operation: doDeleteStudiePageIndex
// ====================================================

export const doDeleteStudiePageIndexMutation = async (
    variables: deleteStudiePageIndexMutationVariables
): Promise<GraphqlResult<deleteStudiePageIndexMutation>> => {

    const document = gql`mutation deleteStudiePageIndexMutation($input: DeleteStudiePageIndexInput!){
deleteStudiePageIndex(input: $input)
}
`;

    return await BridgeDrop.bridge.session.mutate<deleteStudiePageIndexMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doDeleteStudiePage
// ====================================================

export const doDeleteStudiePageMutation = async (
    variables: deleteStudiePageMutationVariables
): Promise<GraphqlResult<deleteStudiePageMutation>> => {

    const document = gql`mutation deleteStudiePageMutation($input: DeleteStudiePageInput!){
deleteStudiePage(input: $input)
}
`;

    return await BridgeDrop.bridge.session.mutate<deleteStudiePageMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doDeleteHomePage
// ====================================================

export const doDeleteHomePageMutation = async (
    variables: deleteHomePageMutationVariables
): Promise<GraphqlResult<deleteHomePageMutation>> => {

    const document = gql`mutation deleteHomePageMutation($input: DeleteHomePageInput!){
deleteHomePage(input: $input)
}
`;

    return await BridgeDrop.bridge.session.mutate<deleteHomePageMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doUpdateHomePage
// ====================================================

export const doUpdateHomePageMutation = async (
    variables: updateHomePageMutationVariables
): Promise<GraphqlResult<updateHomePageMutation>> => {

    const document = gql`fragment streamFieldInterfaceFields_updateHomePageMutation on StreamFieldInterface { __typename
id
blockType
field
rawValue... on StreamFieldBlock{...streamFieldBlockFields_updateHomePageMutation}... on CharBlock{...charBlockFields_updateHomePageMutation}... on TextBlock{...textBlockFields_updateHomePageMutation}... on EmailBlock{...emailBlockFields_updateHomePageMutation}... on IntegerBlock{...integerBlockFields_updateHomePageMutation}... on FloatBlock{...floatBlockFields_updateHomePageMutation}... on DecimalBlock{...decimalBlockFields_updateHomePageMutation}... on RegexBlock{...regexBlockFields_updateHomePageMutation}... on URLBlock{...uRLBlockFields_updateHomePageMutation}... on BooleanBlock{...booleanBlockFields_updateHomePageMutation}... on DateBlock{...dateBlockFields_updateHomePageMutation}... on TimeBlock{...timeBlockFields_updateHomePageMutation}... on DateTimeBlock{...dateTimeBlockFields_updateHomePageMutation}... on RichTextBlock{...richTextBlockFields_updateHomePageMutation}... on RawHTMLBlock{...rawHTMLBlockFields_updateHomePageMutation}... on BlockQuoteBlock{...blockQuoteBlockFields_updateHomePageMutation}... on ChoiceBlock{...choiceBlockFields_updateHomePageMutation}... on StreamBlock{...streamBlockFields_updateHomePageMutation}... on StructBlock{...structBlockFields_updateHomePageMutation}... on StaticBlock{...staticBlockFields_updateHomePageMutation}... on ListBlock{...listBlockFields_updateHomePageMutation}... on EmbedBlock{...embedBlockFields_updateHomePageMutation}... on ImageGalleryImage{...imageGalleryImageFields_updateHomePageMutation}... on ImageGalleryImages{...imageGalleryImagesFields_updateHomePageMutation}... on ImageGalleryBlock{...imageGalleryBlockFields_updateHomePageMutation}... on VideoBlock{...videoBlockFields_updateHomePageMutation}... on DocumentChooserBlock{...documentChooserBlockFields_updateHomePageMutation}... on ImageChooserBlock{...imageChooserBlockFields_updateHomePageMutation}... on SnippetChooserBlock{...snippetChooserBlockFields_updateHomePageMutation}}
fragment streamFieldBlockFields_updateHomePageMutation on StreamFieldBlock { __typename
id
blockType
field
rawValue
value}
fragment charBlockFields_updateHomePageMutation on CharBlock { __typename
id
blockType
field
rawValue
value}
fragment textBlockFields_updateHomePageMutation on TextBlock { __typename
id
blockType
field
rawValue
value}
fragment emailBlockFields_updateHomePageMutation on EmailBlock { __typename
id
blockType
field
rawValue
value}
fragment integerBlockFields_updateHomePageMutation on IntegerBlock { __typename
id
blockType
field
rawValue
value}
fragment floatBlockFields_updateHomePageMutation on FloatBlock { __typename
id
blockType
field
rawValue
value}
fragment decimalBlockFields_updateHomePageMutation on DecimalBlock { __typename
id
blockType
field
rawValue
value}
fragment regexBlockFields_updateHomePageMutation on RegexBlock { __typename
id
blockType
field
rawValue
value}
fragment uRLBlockFields_updateHomePageMutation on URLBlock { __typename
id
blockType
field
rawValue
value}
fragment booleanBlockFields_updateHomePageMutation on BooleanBlock { __typename
id
blockType
field
rawValue
value}
fragment dateBlockFields_updateHomePageMutation on DateBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment timeBlockFields_updateHomePageMutation on TimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment dateTimeBlockFields_updateHomePageMutation on DateTimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment richTextBlockFields_updateHomePageMutation on RichTextBlock { __typename
id
blockType
field
rawValue
value}
fragment rawHTMLBlockFields_updateHomePageMutation on RawHTMLBlock { __typename
id
blockType
field
rawValue
value}
fragment blockQuoteBlockFields_updateHomePageMutation on BlockQuoteBlock { __typename
id
blockType
field
rawValue
value}
fragment choiceOptionFields_updateHomePageMutation on ChoiceOption { __typename
key
value}
fragment choiceBlockFields_updateHomePageMutation on ChoiceBlock { __typename
id
blockType
field
rawValue
value
choices { ...choiceOptionFields_updateHomePageMutation}}
fragment streamBlockFields_updateHomePageMutation on StreamBlock { __typename
id
blockType
field
rawValue}
fragment structBlockFields_updateHomePageMutation on StructBlock { __typename
id
blockType
field
rawValue}
fragment staticBlockFields_updateHomePageMutation on StaticBlock { __typename
id
blockType
field
rawValue
value}
fragment listBlockFields_updateHomePageMutation on ListBlock { __typename
id
blockType
field
rawValue
items{ __typename }}
fragment embedBlockFields_updateHomePageMutation on EmbedBlock { __typename
id
blockType
field
rawValue
value
url
embed
rawEmbed}
fragment imageGalleryImageFields_updateHomePageMutation on ImageGalleryImage { __typename
id
blockType
field
rawValue}
fragment imageGalleryImagesFields_updateHomePageMutation on ImageGalleryImages { __typename
id
blockType
field
rawValue}
fragment imageGalleryBlockFields_updateHomePageMutation on ImageGalleryBlock { __typename
id
blockType
field
rawValue}
fragment videoBlockFields_updateHomePageMutation on VideoBlock { __typename
id
blockType
field
rawValue}
fragment sNEKDocumentFields_updateHomePageMutation on SNEKDocument { __typename
title
file
createdAt
fileSize
fileHash
id}
fragment documentChooserBlockFields_updateHomePageMutation on DocumentChooserBlock { __typename
id
blockType
field
rawValue
document { ...sNEKDocumentFields_updateHomePageMutation}}
fragment renditionFields_updateHomePageMutation on Rendition { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality){ __typename }
srcSet(sizes: $sizes)}
fragment sNEKImageFields_updateHomePageMutation on SNEKImage { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality) { ...renditionFields_updateHomePageMutation}
srcSet(sizes: $sizes)}
fragment imageChooserBlockFields_updateHomePageMutation on ImageChooserBlock { __typename
id
blockType
field
rawValue
image { ...sNEKImageFields_updateHomePageMutation}}
fragment snippetChooserBlockFields_updateHomePageMutation on SnippetChooserBlock { __typename
id
blockType
field
rawValue
snippet}
fragment homePageFields_updateHomePageMutation on HomePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
city
zipCode
address
telephone
telefax
vatNumber
whatsappTelephone
whatsappContactline
taxId
courtOfRegistry
placeOfRegistry
tradeRegisterNumber
ownership
email
copyrightholder
about
privacy
body { ...streamFieldInterfaceFields_updateHomePageMutation}
url
pageType
seoDescription}
mutation updateHomePageMutation($format: String, $max: String, $min: String, $width: Int, $height: Int, $fill: String, $bgcolor: String, $jpegquality: Int, $sizes: [Int], $input: UpdateHomePageInput!, $id: ID!){
updateHomePage(input: $input, id: $id) { ...homePageFields_updateHomePageMutation}
}
`;

    return await BridgeDrop.bridge.session.mutate<updateHomePageMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doCreateHomePage
// ====================================================

export const doCreateHomePageMutation = async (
    variables: createHomePageMutationVariables
): Promise<GraphqlResult<createHomePageMutation>> => {

    const document = gql`fragment streamFieldInterfaceFields_createHomePageMutation on StreamFieldInterface { __typename
id
blockType
field
rawValue... on StreamFieldBlock{...streamFieldBlockFields_createHomePageMutation}... on CharBlock{...charBlockFields_createHomePageMutation}... on TextBlock{...textBlockFields_createHomePageMutation}... on EmailBlock{...emailBlockFields_createHomePageMutation}... on IntegerBlock{...integerBlockFields_createHomePageMutation}... on FloatBlock{...floatBlockFields_createHomePageMutation}... on DecimalBlock{...decimalBlockFields_createHomePageMutation}... on RegexBlock{...regexBlockFields_createHomePageMutation}... on URLBlock{...uRLBlockFields_createHomePageMutation}... on BooleanBlock{...booleanBlockFields_createHomePageMutation}... on DateBlock{...dateBlockFields_createHomePageMutation}... on TimeBlock{...timeBlockFields_createHomePageMutation}... on DateTimeBlock{...dateTimeBlockFields_createHomePageMutation}... on RichTextBlock{...richTextBlockFields_createHomePageMutation}... on RawHTMLBlock{...rawHTMLBlockFields_createHomePageMutation}... on BlockQuoteBlock{...blockQuoteBlockFields_createHomePageMutation}... on ChoiceBlock{...choiceBlockFields_createHomePageMutation}... on StreamBlock{...streamBlockFields_createHomePageMutation}... on StructBlock{...structBlockFields_createHomePageMutation}... on StaticBlock{...staticBlockFields_createHomePageMutation}... on ListBlock{...listBlockFields_createHomePageMutation}... on EmbedBlock{...embedBlockFields_createHomePageMutation}... on ImageGalleryImage{...imageGalleryImageFields_createHomePageMutation}... on ImageGalleryImages{...imageGalleryImagesFields_createHomePageMutation}... on ImageGalleryBlock{...imageGalleryBlockFields_createHomePageMutation}... on VideoBlock{...videoBlockFields_createHomePageMutation}... on DocumentChooserBlock{...documentChooserBlockFields_createHomePageMutation}... on ImageChooserBlock{...imageChooserBlockFields_createHomePageMutation}... on SnippetChooserBlock{...snippetChooserBlockFields_createHomePageMutation}}
fragment streamFieldBlockFields_createHomePageMutation on StreamFieldBlock { __typename
id
blockType
field
rawValue
value}
fragment charBlockFields_createHomePageMutation on CharBlock { __typename
id
blockType
field
rawValue
value}
fragment textBlockFields_createHomePageMutation on TextBlock { __typename
id
blockType
field
rawValue
value}
fragment emailBlockFields_createHomePageMutation on EmailBlock { __typename
id
blockType
field
rawValue
value}
fragment integerBlockFields_createHomePageMutation on IntegerBlock { __typename
id
blockType
field
rawValue
value}
fragment floatBlockFields_createHomePageMutation on FloatBlock { __typename
id
blockType
field
rawValue
value}
fragment decimalBlockFields_createHomePageMutation on DecimalBlock { __typename
id
blockType
field
rawValue
value}
fragment regexBlockFields_createHomePageMutation on RegexBlock { __typename
id
blockType
field
rawValue
value}
fragment uRLBlockFields_createHomePageMutation on URLBlock { __typename
id
blockType
field
rawValue
value}
fragment booleanBlockFields_createHomePageMutation on BooleanBlock { __typename
id
blockType
field
rawValue
value}
fragment dateBlockFields_createHomePageMutation on DateBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment timeBlockFields_createHomePageMutation on TimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment dateTimeBlockFields_createHomePageMutation on DateTimeBlock { __typename
id
blockType
field
rawValue
value(format: $format)}
fragment richTextBlockFields_createHomePageMutation on RichTextBlock { __typename
id
blockType
field
rawValue
value}
fragment rawHTMLBlockFields_createHomePageMutation on RawHTMLBlock { __typename
id
blockType
field
rawValue
value}
fragment blockQuoteBlockFields_createHomePageMutation on BlockQuoteBlock { __typename
id
blockType
field
rawValue
value}
fragment choiceOptionFields_createHomePageMutation on ChoiceOption { __typename
key
value}
fragment choiceBlockFields_createHomePageMutation on ChoiceBlock { __typename
id
blockType
field
rawValue
value
choices { ...choiceOptionFields_createHomePageMutation}}
fragment streamBlockFields_createHomePageMutation on StreamBlock { __typename
id
blockType
field
rawValue}
fragment structBlockFields_createHomePageMutation on StructBlock { __typename
id
blockType
field
rawValue}
fragment staticBlockFields_createHomePageMutation on StaticBlock { __typename
id
blockType
field
rawValue
value}
fragment listBlockFields_createHomePageMutation on ListBlock { __typename
id
blockType
field
rawValue
items{ __typename }}
fragment embedBlockFields_createHomePageMutation on EmbedBlock { __typename
id
blockType
field
rawValue
value
url
embed
rawEmbed}
fragment imageGalleryImageFields_createHomePageMutation on ImageGalleryImage { __typename
id
blockType
field
rawValue}
fragment imageGalleryImagesFields_createHomePageMutation on ImageGalleryImages { __typename
id
blockType
field
rawValue}
fragment imageGalleryBlockFields_createHomePageMutation on ImageGalleryBlock { __typename
id
blockType
field
rawValue}
fragment videoBlockFields_createHomePageMutation on VideoBlock { __typename
id
blockType
field
rawValue}
fragment sNEKDocumentFields_createHomePageMutation on SNEKDocument { __typename
title
file
createdAt
fileSize
fileHash
id}
fragment documentChooserBlockFields_createHomePageMutation on DocumentChooserBlock { __typename
id
blockType
field
rawValue
document { ...sNEKDocumentFields_createHomePageMutation}}
fragment renditionFields_createHomePageMutation on Rendition { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality){ __typename }
srcSet(sizes: $sizes)}
fragment sNEKImageFields_createHomePageMutation on SNEKImage { __typename
width
height
id
src
aspectRatio
sizes
rendition(max: $max, min: $min, width: $width, height: $height, fill: $fill, format: $format, bgcolor: $bgcolor, jpegquality: $jpegquality) { ...renditionFields_createHomePageMutation}
srcSet(sizes: $sizes)}
fragment imageChooserBlockFields_createHomePageMutation on ImageChooserBlock { __typename
id
blockType
field
rawValue
image { ...sNEKImageFields_createHomePageMutation}}
fragment snippetChooserBlockFields_createHomePageMutation on SnippetChooserBlock { __typename
id
blockType
field
rawValue
snippet}
fragment homePageFields_createHomePageMutation on HomePage { __typename
id
depth
title
slug
contentType
urlPath
seoTitle
showInMenus
lastPublishedAt
city
zipCode
address
telephone
telefax
vatNumber
whatsappTelephone
whatsappContactline
taxId
courtOfRegistry
placeOfRegistry
tradeRegisterNumber
ownership
email
copyrightholder
about
privacy
body { ...streamFieldInterfaceFields_createHomePageMutation}
url
pageType
seoDescription}
mutation createHomePageMutation($format: String, $max: String, $min: String, $width: Int, $height: Int, $fill: String, $bgcolor: String, $jpegquality: Int, $sizes: [Int], $input: CreateHomePageInput!){
createHomePage(input: $input) { ...homePageFields_createHomePageMutation}
}
`;

    return await BridgeDrop.bridge.session.mutate<createHomePageMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doDeleteSocialMediaSettings
// ====================================================

export const doDeleteSocialMediaSettingsMutation = async (
    variables: deleteSocialMediaSettingsMutationVariables
): Promise<GraphqlResult<deleteSocialMediaSettingsMutation>> => {

    const document = gql`mutation deleteSocialMediaSettingsMutation($input: DeleteSocialMediaSettingsInput!){
deleteSocialMediaSettings(input: $input)
}
`;

    return await BridgeDrop.bridge.session.mutate<deleteSocialMediaSettingsMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doTokenAuth
// ====================================================

export const doTokenAuthMutation = async (
    variables: tokenAuthMutationVariables
): Promise<GraphqlResult<tokenAuthMutation>> => {

    const document = gql`fragment userTypeFields_tokenAuthMutation on UserType { __typename
id
username}
fragment obtainJSONWebTokenFields_tokenAuthMutation on ObtainJSONWebToken { __typename
payload
refreshExpiresIn
user { ...userTypeFields_tokenAuthMutation}
token
refreshToken}
mutation tokenAuthMutation($username: String!, $password: String!){
tokenAuth(username: $username, password: $password) { ...obtainJSONWebTokenFields_tokenAuthMutation}
}
`;

    return await BridgeDrop.bridge.session.mutate<tokenAuthMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doVerifyToken
// ====================================================

export const doVerifyTokenMutation = async (
    variables: verifyTokenMutationVariables
): Promise<GraphqlResult<verifyTokenMutation>> => {

    const document = gql`fragment verifyFields_verifyTokenMutation on Verify { __typename
payload}
mutation verifyTokenMutation($token: String){
verifyToken(token: $token) { ...verifyFields_verifyTokenMutation}
}
`;

    return await BridgeDrop.bridge.session.mutate<verifyTokenMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doRefreshToken
// ====================================================

export const doRefreshTokenMutation = async (
    variables: refreshTokenMutationVariables
): Promise<GraphqlResult<refreshTokenMutation>> => {

    const document = gql`fragment refreshFields_refreshTokenMutation on Refresh { __typename
payload
refreshExpiresIn
token
refreshToken}
mutation refreshTokenMutation($refreshToken: String){
refreshToken(refreshToken: $refreshToken) { ...refreshFields_refreshTokenMutation}
}
`;

    return await BridgeDrop.bridge.session.mutate<refreshTokenMutation>(
      document,
      variables
    );
}

// ====================================================
// Bridge operation: doRevokeToken
// ====================================================

export const doRevokeTokenMutation = async (
    variables: revokeTokenMutationVariables
): Promise<GraphqlResult<revokeTokenMutation>> => {

    const document = gql`fragment revokeFields_revokeTokenMutation on Revoke { __typename
revoked}
mutation revokeTokenMutation($refreshToken: String){
revokeToken(refreshToken: $refreshToken) { ...revokeFields_revokeTokenMutation}
}
`;

    return await BridgeDrop.bridge.session.mutate<revokeTokenMutation>(
      document,
      variables
    );
}
