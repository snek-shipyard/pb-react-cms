/**
 * @license
 * Copyright Nico Schett. All Rights Reserved.
 */
import { BifrostBridge } from 'bridge';
import * as mutations from './mutations.gen';
import * as queries from './queries.gen';
export default class BridgeDrop {
    static bridge: BifrostBridge;
    static buildIn: {
        mutations: typeof mutations;
        queries: typeof queries;
    };
}
