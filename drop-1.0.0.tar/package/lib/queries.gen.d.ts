/**
 * @license
 * Copyright Nico Schett. All Rights Reserved.
 */
import { GraphqlResult } from "bridge/lib/types";
import { meQuery, meQueryVariables, readStudiePageIndexQuery, readStudiePageIndexQueryVariables, readStudiePageQuery, readStudiePageQueryVariables, readHomePageQuery, readHomePageQueryVariables, readSocialMediaSettingsQuery, readSocialMediaSettingsQueryVariables, pagesQuery, pagesQueryVariables, pageQuery, pageQueryVariables } from "./types.gen";
export declare const doMeQuery: (variables: meQueryVariables) => Promise<GraphqlResult<meQuery>>;
export declare const doReadStudiePageIndexQuery: (variables: readStudiePageIndexQueryVariables) => Promise<GraphqlResult<readStudiePageIndexQuery>>;
export declare const doReadStudiePageQuery: (variables: readStudiePageQueryVariables) => Promise<GraphqlResult<readStudiePageQuery>>;
export declare const doReadHomePageQuery: (variables: readHomePageQueryVariables) => Promise<GraphqlResult<readHomePageQuery>>;
export declare const doReadSocialMediaSettingsQuery: (variables: readSocialMediaSettingsQueryVariables) => Promise<GraphqlResult<readSocialMediaSettingsQuery>>;
export declare const doPagesQuery: (variables: pagesQueryVariables) => Promise<GraphqlResult<pagesQuery>>;
export declare const doPageQuery: (variables: pageQueryVariables) => Promise<GraphqlResult<pageQuery>>;
