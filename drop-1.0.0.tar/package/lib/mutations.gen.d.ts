/**
 * @license
 * Copyright Nico Schett. All Rights Reserved.
 */
import { GraphqlResult } from "bridge/lib/types";
import { deleteStudiePageIndexMutation, deleteStudiePageIndexMutationVariables, deleteStudiePageMutation, deleteStudiePageMutationVariables, deleteHomePageMutation, deleteHomePageMutationVariables, updateHomePageMutation, updateHomePageMutationVariables, createHomePageMutation, createHomePageMutationVariables, deleteSocialMediaSettingsMutation, deleteSocialMediaSettingsMutationVariables, tokenAuthMutation, tokenAuthMutationVariables, verifyTokenMutation, verifyTokenMutationVariables, refreshTokenMutation, refreshTokenMutationVariables, revokeTokenMutation, revokeTokenMutationVariables } from "./types.gen";
export declare const doDeleteStudiePageIndexMutation: (variables: deleteStudiePageIndexMutationVariables) => Promise<GraphqlResult<deleteStudiePageIndexMutation>>;
export declare const doDeleteStudiePageMutation: (variables: deleteStudiePageMutationVariables) => Promise<GraphqlResult<deleteStudiePageMutation>>;
export declare const doDeleteHomePageMutation: (variables: deleteHomePageMutationVariables) => Promise<GraphqlResult<deleteHomePageMutation>>;
export declare const doUpdateHomePageMutation: (variables: updateHomePageMutationVariables) => Promise<GraphqlResult<updateHomePageMutation>>;
export declare const doCreateHomePageMutation: (variables: createHomePageMutationVariables) => Promise<GraphqlResult<createHomePageMutation>>;
export declare const doDeleteSocialMediaSettingsMutation: (variables: deleteSocialMediaSettingsMutationVariables) => Promise<GraphqlResult<deleteSocialMediaSettingsMutation>>;
export declare const doTokenAuthMutation: (variables: tokenAuthMutationVariables) => Promise<GraphqlResult<tokenAuthMutation>>;
export declare const doVerifyTokenMutation: (variables: verifyTokenMutationVariables) => Promise<GraphqlResult<verifyTokenMutation>>;
export declare const doRefreshTokenMutation: (variables: refreshTokenMutationVariables) => Promise<GraphqlResult<refreshTokenMutation>>;
export declare const doRevokeTokenMutation: (variables: revokeTokenMutationVariables) => Promise<GraphqlResult<revokeTokenMutation>>;
